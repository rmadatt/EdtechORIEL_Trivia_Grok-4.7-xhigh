import type { Puzzle } from "../data/puzzles";

const FILLER = new Set([
  "the",
  "a",
  "an",
  "of",
  "city",
  "please",
  "answer",
  "its",
  "it's",
  "it",
  "is",
]);

export function compact(raw: string): string {
  let s = raw.toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
  s = s.replace(/π/g, "pi").replace(/&/g, " and ").replace(/-/g, "");
  s = s.replace(/(?<!\d)\.(?!\d)/g, "");
  s = s.replace(/[^a-z0-9.+/-]+/g, " ");
  const tokens = s
    .trim()
    .split(/\s+/)
    .filter((t) => t && !FILLER.has(t));
  return tokens.join("");
}

export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const prev = new Array<number>(b.length + 1);
  const curr = new Array<number>(b.length + 1);
  for (let j = 0; j <= b.length; j++) prev[j] = j;
  for (let i = 1; i <= a.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= b.length; j++) prev[j] = curr[j];
  }
  return prev[b.length];
}

function closest(c: string, words: string[]): number {
  let best = 99;
  for (const w of words) {
    const wc = compact(w);
    if (!wc) continue;
    best = Math.min(best, levenshtein(c, wc));
  }
  return best;
}

function bestNudge(
  c: string,
  groups: { words: string[]; nudge: string }[],
): { dist: number; nudge: string } {
  let best = { dist: 99, nudge: "" };
  for (const g of groups) {
    const dist = closest(c, g.words);
    if (dist < best.dist) best = { dist, nudge: g.nudge };
  }
  return best;
}

export type Judge =
  | { kind: "empty" }
  | { kind: "correct"; fuzzy: boolean }
  | { kind: "literal"; message: string }
  | { kind: "near"; message: string }
  | { kind: "other"; message: string }
  | { kind: "wrong" };

function allowed(len: number): number {
  if (len >= 9) return 2;
  if (len >= 5) return 1;
  return 0;
}

export function judge(raw: string, puzzle: Puzzle, all: Puzzle[]): Judge {
  const c = compact(raw);
  if (!c) return { kind: "empty" };

  if (puzzle.id === "pi" && /^3\.14\d*$/.test(c)) {
    return { kind: "correct", fuzzy: false };
  }

  const targets = [puzzle.answer, ...puzzle.aliases].map(compact).filter(Boolean);
  const ansDist = Math.min(...targets.map((t) => levenshtein(c, t)));
  const bestLen = targets.reduce((m, t) => (levenshtein(c, t) === ansDist ? Math.max(m, t.length) : m), 0);
  const lit = bestNudge(c, puzzle.literal);
  const near = bestNudge(c, puzzle.near ?? []);

  if (ansDist === 0) return { kind: "correct", fuzzy: false };
  if (lit.dist === 0) return { kind: "literal", message: lit.nudge };
  if (near.dist === 0) return { kind: "near", message: near.nudge };

  if (
    ansDist > 0 &&
    ansDist <= allowed(bestLen) &&
    ansDist < lit.dist &&
    ansDist < near.dist
  ) {
    return { kind: "correct", fuzzy: true };
  }

  if (lit.dist === 1 && c.length >= 4) return { kind: "literal", message: lit.nudge };
  if (near.dist === 1 && c.length >= 4) return { kind: "near", message: near.nudge };

  if (c.length >= 4) {
    for (const other of all) {
      if (other.id === puzzle.id) continue;
      const otherTargets = [other.answer, ...other.aliases].map(compact);
      if (otherTargets.includes(c)) {
        return {
          kind: "other",
          message: `That name belongs in another frame — this one is still wearing its costume.`,
        };
      }
    }
  }

  return { kind: "wrong" };
}

export function pointsFor(hints: number, seconds: number, streakBefore: number): number {
  const costs = [0, 28, 62, 96];
  const cost = costs[Math.min(3, hints)] ?? 96;
  const bonus = hints === 0 ? Math.max(0, 32 - Math.floor(seconds)) : 0;
  const streak = streakBefore >= 1 ? streakBefore * 6 : 0;
  return Math.max(12, 100 - cost + bonus + streak);
}

export function todayKey(d = new Date()): string {
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function yesterdayKey(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return todayKey(d);
}
