import {
  Angel,
  Drums,
  Frame,
  Gent,
  Log,
  Pie,
  Plus,
  Rabbit,
  Radio,
  Signpost,
  SquareVeg,
  Star,
  TeaJar,
} from "./kit";

export function SevenScene() {
  const ring = Array.from({ length: 6 }, (_, i) => {
    const a = -Math.PI / 2 + (i * Math.PI) / 3;
    return [400 + Math.cos(a) * 148, 230 + Math.sin(a) * 120];
  });
  return (
    <Frame id="seven" from="#1b2744" to="#2a1c38" ground={false}>
      <circle cx="640" cy="78" r="26" fill="#f4e7c4" opacity="0.9" />
      {ring.map(([x, y], i) => (
        <line
          key={i}
          x1={400}
          y1={230}
          x2={x}
          y2={y}
          stroke="#e0b15a"
          strokeWidth="1"
          opacity="0.35"
        />
      ))}
      {ring.map(([x, y], i) => (
        <Star key={i} x={x} y={y} r={i % 2 ? 20 : 26} delay={i * 0.35} />
      ))}
      <Star x={400} y={230} r={30} delay={0.2} />
    </Frame>
  );
}

export function PiScene() {
  return (
    <Frame id="pi" from="#f6e7cf" to="#f3d7b4">
      <Pie x={400} y={300} s={1.7} />
    </Frame>
  );
}

export function AcuteScene() {
  return (
    <Frame id="acute" from="#f7f1e6" to="#e7f0ea">
      <Angel x={360} y={400} s={1.35} />
    </Frame>
  );
}

export function TangentScene() {
  return (
    <Frame id="tangent" from="#f8e7c4" to="#d7eef4">
      <circle cx="545" cy="230" r="118" fill="#d5eef6" stroke="#2f6f86" strokeWidth="3.2" />
      <line x1="160" y1="112" x2="700" y2="112" stroke="#8d5a32" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="545" cy="112" r="5" fill="#e0b15a" stroke="#2b241c" strokeWidth="1" />
      <Gent x={200} y={430} s={1.15} />
    </Frame>
  );
}

export function LogarithmScene() {
  return (
    <Frame id="logarithm" from="#e7f0e4" to="#e6d3b8">
      <Log x={250} y={360} s={1.25} />
      <Plus x={430} y={250} />
      <Drums x={580} y={360} s={1.3} />
    </Frame>
  );
}

export function IntegerScene() {
  return (
    <Frame id="integer" from="#f6e7cf" to="#f3dcc0">
      <TeaJar x={400} y={400} s={1.55} />
    </Frame>
  );
}

export function RadiusScene() {
  return (
    <Frame id="radius" from="#f3e6cf" to="#e7eef2">
      <Radio x={400} y={340} s={1.45} />
    </Frame>
  );
}

export function SquareRootScene() {
  return (
    <Frame id="squareroot" from="#e7f0e4" to="#e4c9a4">
      <ellipse cx="400" cy="430" rx="160" ry="22" fill="#8d5a32" opacity="0.35" />
      <SquareVeg x={400} y={430} s={1.2} />
    </Frame>
  );
}

export function SineScene() {
  return (
    <Frame id="sine" from="#d5e8f2" to="#e7e0d0">
      <Signpost x={400} y={420} s={1.45} />
    </Frame>
  );
}

export function FibonacciScene() {
  const groups = [1, 1, 2, 3, 5];
  const starts = [90, 210, 330, 470, 620];
  return (
    <Frame id="fibonacci" from="#e7f2e4" to="#f6f1e6">
      {groups.map((n, gi) => (
        <g key={gi}>
          <ellipse cx={starts[gi] + 16} cy="438" rx={18 + n * 8} ry="10" fill="#b7c9a4" />
          {Array.from({ length: n }, (_, i) => (
            <Rabbit
              key={i}
              x={starts[gi] + (i % 3) * 26 - 8}
              y={405 - Math.floor(i / 3) * 28}
              s={0.9}
            />
          ))}
          {gi < groups.length - 1 && (
            <path
              d={`M${starts[gi] + 48} 250 h14 M${starts[gi] + 55} 243 v14`}
              stroke="#2b241c"
              strokeWidth="1.6"
              opacity="0.35"
              strokeLinecap="round"
            />
          )}
        </g>
      ))}
    </Frame>
  );
}
