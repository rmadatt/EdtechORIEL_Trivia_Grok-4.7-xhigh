import type { ReactNode } from "react";

export const ink = "#2b241c";

type Place = { x?: number; y?: number; s?: number; flip?: boolean };

function g({ x = 0, y = 0, s = 1, flip = false }: Place) {
  return `translate(${x} ${y}) scale(${flip ? -s : s} ${s})`;
}

export function Frame({
  id,
  from,
  to,
  children,
  ground = true,
  defs,
}: {
  id: string;
  from: string;
  to: string;
  children: ReactNode;
  ground?: boolean;
  defs?: ReactNode;
}) {
  return (
    <svg viewBox="0 0 800 500" className="h-full w-full" aria-hidden="true">
      <defs>
        <linearGradient id={`${id}-bg`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={from} />
          <stop offset="100%" stopColor={to} />
        </linearGradient>
        {defs}
      </defs>
      <rect width="800" height="500" fill={`url(#${id}-bg)`} />
      {ground && <ellipse cx="400" cy="468" rx="280" ry="14" fill={ink} opacity="0.07" />}
      {children}
    </svg>
  );
}

export function Plus({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`} opacity="0.72">
      <circle r="15" fill="#fffaf2" stroke={ink} strokeWidth="1.6" />
      <path d="M-6 0h12M0-6v12" stroke={ink} strokeWidth="2" strokeLinecap="round" />
    </g>
  );
}

export function Snow() {
  const flakes = [
    [48, 36], [110, 78], [186, 28], [250, 96], [330, 44], [410, 82],
    [490, 30], [560, 70], [640, 40], [720, 88], [90, 150], [700, 140], [380, 120],
  ];
  return (
    <g fill="#fff" opacity="0.85">
      {flakes.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i % 3 === 0 ? 2.3 : 1.3} />
      ))}
    </g>
  );
}

export function Rain() {
  const drops = Array.from({ length: 18 }, (_, i) => [30 + ((i * 47) % 760), 20 + ((i * 29) % 180)] as const);
  return (
    <g stroke="#7f97a8" strokeWidth="1.4" strokeLinecap="round" opacity="0.45">
      {drops.map(([x, y], i) => (
        <path key={i} d={`M${x} ${y} l-6 16`} />
      ))}
    </g>
  );
}

export function Hills({ fill = "#c5d2c4", y = 390 }: { fill?: string; y?: number }) {
  return (
    <path
      d={`M0 ${y + 30} C80 ${y - 30} 160 ${y + 10} 250 ${y - 8} C360 ${y - 36} 430 ${y + 8} 520 ${y - 16} C640 ${y - 40} 700 ${y + 6} 800 ${y - 12} V500 H0 Z`}
      fill={fill}
    />
  );
}

export function Cow({ x = 0, y = 0, s = 1, flip = false }: Place) {
  return (
    <g transform={g({ x, y, s, flip })}>
      <ellipse cx="4" cy="2" rx="62" ry="9" fill={ink} opacity="0.08" />
      <path d="M-62 -58c-14 10 -12 30 -2 34" fill="none" stroke={ink} strokeWidth="2.2" strokeLinecap="round" />
      <circle cx="-66" cy="-22" r="6" fill="#3a3228" />
      <ellipse cx="-2" cy="-52" rx="58" ry="34" fill="#f7f3ea" stroke={ink} strokeWidth="2.3" />
      <ellipse cx="-22" cy="-62" rx="16" ry="11" fill="#3a3228" />
      <ellipse cx="22" cy="-42" rx="12" ry="9" fill="#3a3228" />
      <ellipse cx="-6" cy="-34" rx="8" ry="6" fill="#3a3228" />
      <path d="M28 -78c8 -16 28 -16 34 -2c-8 2 -18 8 -22 16" fill="#f7f3ea" stroke={ink} strokeWidth="2.2" />
      <ellipse cx="62" cy="-66" rx="24" ry="18" fill="#f7f3ea" stroke={ink} strokeWidth="2.3" />
      <path d="M48 -80c2 -14 12 -16 14 -6" fill="none" stroke="#d8c4a4" strokeWidth="3" strokeLinecap="round" />
      <ellipse cx="80" cy="-60" rx="11" ry="8" fill="#f0b8b0" stroke={ink} strokeWidth="2" />
      <circle cx="76" cy="-60" r="1.3" fill={ink} />
      <circle cx="83" cy="-60" r="1.3" fill={ink} />
      <circle cx="66" cy="-70" r="2.6" fill={ink} />
      <circle cx="67" cy="-71" r="0.8" fill="#fff" />
      <path d="M-28 -28v30M-8 -24v28M16 -24v28M36 -28v30" stroke={ink} strokeWidth="6" strokeLinecap="round" />
      <path d="M-34 -2h12M-14 -2h12M10 -2h12M30 -2h12" stroke="#2b241c" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M48 -50 l6 0 2 9 -10 0 z" fill="#e0b15a" stroke={ink} strokeWidth="1.4" />
    </g>
  );
}

export function Ox({ x = 0, y = 0, s = 1, flip = false }: Place) {
  return (
    <g transform={g({ x, y, s, flip })}>
      <ellipse cx="0" cy="2" rx="66" ry="9" fill={ink} opacity="0.08" />
      <ellipse cx="0" cy="-50" rx="62" ry="36" fill="#8d5a32" stroke={ink} strokeWidth="2.3" />
      <ellipse cx="8" cy="-62" rx="28" ry="16" fill="#a56b3e" opacity="0.7" />
      <ellipse cx="58" cy="-70" rx="26" ry="20" fill="#8d5a32" stroke={ink} strokeWidth="2.3" />
      <path d="M40 -84c-2 -18 10 -26 16 -14" fill="none" stroke="#efe6d4" strokeWidth="4" strokeLinecap="round" />
      <path d="M62 -88c6 -16 20 -14 16 0" fill="none" stroke="#efe6d4" strokeWidth="4" strokeLinecap="round" />
      <ellipse cx="80" cy="-64" rx="12" ry="9" fill="#e7b5a4" stroke={ink} strokeWidth="2" />
      <circle cx="76" cy="-64" r="1.3" fill={ink} />
      <circle cx="84" cy="-64" r="1.3" fill={ink} />
      <circle cx="64" cy="-74" r="2.5" fill={ink} />
      <path d="M-30 -26v32M-8 -22v30M18 -22v30M40 -26v32" stroke="#6d4424" strokeWidth="7" strokeLinecap="round" />
      <path d="M-58 -46c-16 8 -14 26 -4 30" fill="none" stroke={ink} strokeWidth="2.2" />
      <circle cx="-64" cy="-14" r="6" fill="#5c3a22" />
    </g>
  );
}

export function Mosque({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-78" y="-118" width="156" height="118" rx="4" fill="#e7c99a" stroke={ink} strokeWidth="2.3" />
      <path d="M-54 -118c0 -62 108 -62 108 0" fill="#2f7d78" stroke={ink} strokeWidth="2.3" />
      <path d="M-28 -150c8 -28 48 -28 56 0" fill="#3e948e" stroke={ink} strokeWidth="2" />
      <circle cx="0" cy="-168" r="4" fill="#e0b15a" stroke={ink} strokeWidth="1.2" />
      <path d="M0 -172 v-16" stroke={ink} strokeWidth="1.6" />
      <path d="M-7 -186 a8 8 0 1 1 10 8" fill="none" stroke="#e0b15a" strokeWidth="2" />
      <path d="M-18 -78 v58 h36 v-58 a18 18 0 0 0 -36 0z" fill="#8d3a32" stroke={ink} strokeWidth="2" />
      <path d="M-46 -78 h18 v34 h-18z M28 -78 h18 v34 h-18z" fill="#f6f1e6" stroke={ink} strokeWidth="1.6" />
      <path d="M-40 -78 v34 M-28 -78 v34 M34 -78 v34 M46 -78 v34" stroke={ink} strokeWidth="1" opacity="0.4" />
      {[-96, 96].map((mx) => (
        <g key={mx}>
          <rect x={mx - 14} y="-168" width="28" height="168" fill="#efd2a4" stroke={ink} strokeWidth="2.2" />
          <rect x={mx - 18} y="-96" width="36" height="8" fill="#2f7d78" stroke={ink} strokeWidth="1.4" />
          <path d={`M${mx - 14} -168 h28 l-4 -22 h-20z`} fill="#2f7d78" stroke={ink} strokeWidth="1.8" />
          <circle cx={mx} cy="-196" r="3" fill="#e0b15a" />
        </g>
      ))}
    </g>
  );
}

export function Hen({ x = 0, y = 0, s = 1, flip = false, peck = false }: Place & { peck?: boolean }) {
  return (
    <g transform={g({ x, y, s, flip })}>
      <ellipse cx="0" cy="-28" rx="26" ry="18" fill="#f4efe6" stroke={ink} strokeWidth="2.1" />
      <ellipse cx="16" cy={peck ? -24 : -36} rx="12" ry="10" fill="#f7f3ea" stroke={ink} strokeWidth="2" />
      <path d="M8 -46 q6 -14 14 -8 q-6 2 -8 8" fill="#d4534a" stroke={ink} strokeWidth="1.3" />
      <path d={`M26 ${peck ? -22 : -34} l10 3 l-10 4z`} fill="#e0a04a" stroke={ink} strokeWidth="1.2" />
      <circle cx="18" cy={peck ? -26 : -38} r="1.7" fill={ink} />
      <path d="M-8 -16 l-4 16 M6 -14 l6 16" stroke="#e0a04a" strokeWidth="2.4" strokeLinecap="round" />
      <ellipse cx="-6" cy="-30" rx="10" ry="7" fill="#efe6d6" stroke={ink} strokeWidth="1.3" />
    </g>
  );
}

export function Sink({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-8" y="-36" width="16" height="36" fill="#f7f3ea" stroke={ink} strokeWidth="2" />
      <path d="M-48 -78 h96 v28 c-8 22 -88 22 -96 0z" fill="#f7f7f4" stroke={ink} strokeWidth="2.3" />
      <ellipse cx="0" cy="-62" rx="34" ry="10" fill="#e7eef2" stroke={ink} strokeWidth="1.6" />
      <path d="M-6 -108 v30" stroke="#b7c3c8" strokeWidth="4" strokeLinecap="round" />
      <path d="M-6 -84 h22" stroke="#b7c3c8" strokeWidth="4" strokeLinecap="round" />
      <path d="M16 -84 v10" stroke="#9fb0b6" strokeWidth="3" strokeLinecap="round" />
      <circle cx="0" cy="-58" r="3" fill="#c5a46a" stroke={ink} strokeWidth="1" />
      <path d="M16 -74 q4 8 0 14" fill="none" stroke="#7eb7d4" strokeWidth="1.6" />
    </g>
  );
}

export function Ski({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-16 -150 c0 -20 28 -24 30 -4 l6 140 h-10 l-8 -130z" fill="#f4f7f8" stroke={ink} strokeWidth="2.2" />
      <path d="M8 -150 c0 -20 28 -24 30 -4 l6 140 h-10 l-8 -130z" fill="#dfe8ea" stroke={ink} strokeWidth="2.2" />
      <path d="M-28 -70 l16 -40 M36 -70 l16 -40" stroke="#8d5a32" strokeWidth="3" strokeLinecap="round" />
      <circle cx="-12" cy="-112" r="4" fill="#c45c3a" />
      <circle cx="52" cy="-112" r="4" fill="#c45c3a" />
    </g>
  );
}

export function Tie({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-18 -150 l18 28 l18 -28 l-8 150 l-20 28 l-20 -28z" fill="#8d3a32" stroke={ink} strokeWidth="2.2" />
      <path d="M-8 -122 l8 16 l8 -16" fill="#e0b15a" />
      <path d="M-6 -40 h12 M-4 10 h8" stroke="#e0b15a" strokeWidth="2" opacity="0.7" />
    </g>
  );
}

export function Pie({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="-20" rx="78" ry="26" fill="#c9844a" stroke={ink} strokeWidth="2.3" />
      <path d="M-78 -20 v-16 c0 -28 156 -28 156 0 v16" fill="#e8b07a" stroke={ink} strokeWidth="2.3" />
      <ellipse cx="0" cy="-36" rx="62" ry="20" fill="#f2d2a4" stroke={ink} strokeWidth="1.8" />
      <path d="M-40 -36 l14 -16 M-10 -40 l6 -18 M22 -36 l12 -14" stroke="#c9844a" strokeWidth="2" />
      <path d="M-20 -70 q6 -16 4 -8 M8 -78 q8 -18 2 -6" fill="none" stroke="#fff" strokeWidth="2" opacity="0.8" strokeLinecap="round" />
      <circle cx="-16" cy="-34" r="4" fill="#8d3a32" />
      <circle cx="18" cy="-30" r="3.5" fill="#8d3a32" />
      <circle cx="4" cy="-40" r="3" fill="#6d2e3a" />
    </g>
  );
}

export function Van({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-80 -28 h150 v-36 c0 -28 -20 -40 -40 -40 h-70 c-22 0 -40 12 -40 36z" fill="#f4efe6" stroke={ink} strokeWidth="2.3" />
      <path d="M20 -90 h40 c16 0 22 14 22 28 v34 h-62z" fill="#d7ebe8" stroke={ink} strokeWidth="2.2" />
      <path d="M28 -82 h28 v24 h-28z" fill="#c5e4ef" stroke={ink} strokeWidth="1.6" />
      <circle cx="-36" cy="-18" r="16" fill="#2b241c" />
      <circle cx="-36" cy="-18" r="7" fill="#d9d3c8" />
      <circle cx="46" cy="-18" r="16" fill="#2b241c" />
      <circle cx="46" cy="-18" r="7" fill="#d9d3c8" />
      <rect x="-70" y="-58" width="22" height="14" rx="2" fill="#e0b15a" stroke={ink} strokeWidth="1.3" />
    </g>
  );
}

export function Cooler({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-48 -20 h96 l8 -70 h-112z" fill="#f7f7f4" stroke={ink} strokeWidth="2.3" />
      <path d="M-56 -90 h112 v18 h-112z" fill="#7eb0c9" stroke={ink} strokeWidth="2.2" />
      <rect x="-16" y="-86" width="32" height="10" rx="3" fill="#f7f7f4" stroke={ink} strokeWidth="1.4" />
      <circle cx="-18" cy="-50" r="7" fill="#e7f4f8" stroke="#9fd0e4" strokeWidth="1.4" />
      <circle cx="8" cy="-40" r="5" fill="#e7f4f8" stroke="#9fd0e4" strokeWidth="1.2" />
      <path d="M20 -62 l8 -8 6 4" fill="none" stroke="#7eb0c9" strokeWidth="1.5" />
    </g>
  );
}

export function Car({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-78 -24 h150 c8 0 14 8 12 16 l-8 8 h-158 l-6 -8 c-2 -8 2 -16 10 -16z" fill="#c4473a" stroke={ink} strokeWidth="2.3" />
      <path d="M-20 -24 l16 -28 h48 l18 28z" fill="#f2c1b4" stroke={ink} strokeWidth="2.2" />
      <path d="M-4 -26 l12 -22 h28 l8 22z" fill="#c5e4ef" stroke={ink} strokeWidth="1.4" />
      <circle cx="-40" cy="-8" r="14" fill={ink} />
      <circle cx="-40" cy="-8" r="6" fill="#eee" />
      <circle cx="48" cy="-8" r="14" fill={ink} />
      <circle cx="48" cy="-8" r="6" fill="#eee" />
      <circle cx="62" cy="-22" r="3" fill="#f6e7a8" />
    </g>
  );
}

export function Rowboat({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-70 -10 c20 28 120 28 150 0 l-16 8 c-30 16 -90 16 -120 0z" fill="#c9844a" stroke={ink} strokeWidth="2.2" />
      <path d="M-50 -10 c16 16 90 16 112 0" fill="#e8b07a" />
      <circle cx="-8" cy="-28" r="10" fill="#e0a878" stroke={ink} strokeWidth="1.6" />
      <path d="M-8 -18 v18" stroke="#355f86" strokeWidth="5" strokeLinecap="round" />
      <path d="M-36 -36 l70 8" stroke="#8d5a32" strokeWidth="3" />
      <path d="M-40 -48 l10 16 M28 -24 l8 14" stroke="#d7e4ea" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

export function Runner({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-8 -8 l-26 -8" stroke="#2b241c" strokeWidth="4" strokeLinecap="round" />
      <path d="M22 -6 l24 -2" stroke="#c45c3a" strokeWidth="5" strokeLinecap="round" />
      <path d="M-2 -46 l-24 28" stroke="#2c4660" strokeWidth="6" strokeLinecap="round" />
      <path d="M6 -46 l28 24" stroke="#2c4660" strokeWidth="6" strokeLinecap="round" />
      <path d="M0 -78 c20 -8 36 8 28 20 c-16 4 -36 -4 -36 -12z" fill="#3d6f9a" stroke={ink} strokeWidth="2" />
      <circle cx="34" cy="-84" r="11" fill="#e0a878" stroke={ink} strokeWidth="1.8" />
      <path d="M24 -90 q12 -14 22 -2" fill="#2b241c" />
      <circle cx="38" cy="-85" r="1.3" fill={ink} />
      <path d="M8 -70 l22 16" stroke="#e0a878" strokeWidth="4" strokeLinecap="round" />
      <path d="M4 -66 l-16 10" stroke="#e0a878" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}

export function Don({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-26 -86 h52 l-6 12 h-40z" fill="#1c1915" stroke={ink} strokeWidth="1.6" />
      <rect x="-2" y="-102" width="4" height="16" fill="#e0b15a" />
      <circle cx="0" cy="-78" r="13" fill="#e6c2a4" stroke={ink} strokeWidth="1.8" />
      <path d="M-8 -70 q8 6 16 0" fill="none" stroke={ink} strokeWidth="1.2" />
      <circle cx="-4" cy="-80" r="1.2" fill={ink} />
      <circle cx="5" cy="-80" r="1.2" fill={ink} />
      <path d="M-24 -66 q0 20 8 48 h32 q8 -28 8 -48 q-24 12 -48 0z" fill="#1c1915" stroke={ink} strokeWidth="1.8" />
      <path d="M-6 -64 l6 22 l6 -22" fill="#7c2f2a" />
      <path d="M-8 -18 v18 M8 -18 v18" stroke={ink} strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

export function Sole({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path
        d="M-36 -120 c-28 20 -30 90 -8 150 c14 28 48 36 62 8 c22 -40 28 -120 4 -150 c-14 -16 -40 -22 -58 -8z"
        fill="#d2b48c"
        stroke={ink}
        strokeWidth="2.4"
      />
      <path
        d="M-20 -100 c-16 16 -18 70 -4 120 c10 22 30 28 40 6 c14 -32 16 -96 2 -122 c-8 -12 -28 -16 -38 -4z"
        fill="#c4a47a"
        stroke={ink}
        strokeWidth="1.4"
      />
      {[-70, -40, -10, 20, 50].map((yy) => (
        <g key={yy}>
          <rect x="-8" y={yy} width="10" height="16" rx="2" fill="#a68460" />
          <rect x="8" y={yy} width="10" height="16" rx="2" fill="#a68460" />
        </g>
      ))}
      <ellipse cx="4" cy="-78" rx="16" ry="22" fill="none" stroke={ink} strokeWidth="1.4" opacity="0.35" />
    </g>
  );
}

export function TeaGlass({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-28 -20 h56 l-8 -78 h-40z" fill="#f6e2b0" stroke={ink} strokeWidth="2.2" opacity="0.95" />
      <path d="M-24 -78 h48 l-2 16 h-44z" fill="#c4473a" opacity="0.85" />
      <ellipse cx="0" cy="-98" rx="30" ry="8" fill="#f3d7a4" stroke={ink} strokeWidth="1.8" />
      <path d="M-6 -120 q4 -16 2 -4 M8 -128 q6 -14 1 -2" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" opacity="0.75" />
      <ellipse cx="0" cy="-8" rx="36" ry="8" fill="#e7c98a" stroke={ink} strokeWidth="1.6" />
    </g>
  );
}

export function Deli({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-180 -150 h360 v36 h-360z" fill="#f4efe6" stroke={ink} strokeWidth="2" />
      {Array.from({ length: 9 }).map((_, i) => (
        <rect key={i} x={-180 + i * 40} y="-150" width="20" height="36" fill={i % 2 ? "#c4473a" : "#e0b15a"} />
      ))}
      <rect x="-160" y="-110" width="320" height="110" fill="#f7f1e4" stroke={ink} strokeWidth="2.2" />
      <path d="M-120 -20 h70 v-46 h-70z" fill="#e8c9a0" stroke={ink} strokeWidth="1.6" />
      <path d="M-110 -56 h50 v8 h-50z" fill="#6d8f4e" />
      <path d="M-108 -46 h46 v8 h-46z" fill="#c4473a" />
      <rect x="20" y="-78" width="90" height="58" fill="#f6e7c8" stroke={ink} strokeWidth="1.5" />
      <circle cx="42" cy="-50" r="8" fill="#d2a04a" />
      <circle cx="70" cy="-46" r="7" fill="#c45c3a" />
      <path d="M-40 -150 v-40 M10 -150 v-52 M70 -150 v-36" stroke="#8d5a32" strokeWidth="2" />
      <ellipse cx="-40" cy="-196" rx="12" ry="18" fill="#a33b3b" stroke={ink} strokeWidth="1.3" />
      <ellipse cx="10" cy="-210" rx="14" ry="22" fill="#8d3a32" stroke={ink} strokeWidth="1.3" />
      <ellipse cx="70" cy="-192" rx="11" ry="16" fill="#b4553e" stroke={ink} strokeWidth="1.3" />
    </g>
  );
}

export function Arch({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })} opacity="0.55">
      <path d="M-70 40 v-90 a70 70 0 0 1 140 0 v90" fill="none" stroke="#2f6f86" strokeWidth="10" />
      <path d="M-50 40 v-70 a50 50 0 0 1 100 0 v70" fill="none" stroke="#e0b15a" strokeWidth="4" />
    </g>
  );
}

export function Pyramid({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })} opacity="0.55">
      <path d="M0 -80 L70 20 H-70 Z" fill="#e3c48a" stroke={ink} strokeWidth="1.6" />
      <path d="M0 -80 L28 20 H-8 Z" fill="#c9a56a" opacity="0.7" />
    </g>
  );
}

export function Bridge() {
  return (
    <g opacity="0.4">
      <path d="M80 250 h640" stroke={ink} strokeWidth="3" />
      <path d="M160 250 v-40 M640 250 v-40" stroke={ink} strokeWidth="4" />
      <path d="M160 210 h40 M640 210 h40" stroke={ink} strokeWidth="3" />
      <path d="M200 250 q80 -50 160 0 q80 40 160 0 q80 -40 120 0" fill="none" stroke={ink} strokeWidth="2" />
    </g>
  );
}

export function Parthenon({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })} opacity="0.45">
      <path d="M-50 -40 h100 l-10 -16 h-80z" fill="#e7dcc8" stroke={ink} strokeWidth="1.4" />
      {[-32, -12, 8, 28].map((cx) => (
        <rect key={cx} x={cx} y="-40" width="6" height="36" fill="#efe6d6" stroke={ink} strokeWidth="1" />
      ))}
    </g>
  );
}

export function Mountains() {
  return (
    <g>
      <path d="M0 320 L180 160 L280 250 L390 120 L520 240 L640 150 L800 300 V500 H0 Z" fill="#8aa0ae" opacity="0.45" />
      <path d="M390 120 L430 170 L360 168 Z" fill="#f7f7f4" opacity="0.8" />
      <path d="M180 160 L210 196 L158 190 Z" fill="#f4f7f8" opacity="0.65" />
    </g>
  );
}

export function Pines() {
  return (
    <g opacity="0.55">
      {[80, 150, 640, 710].map((x, i) => (
        <path key={x} d={`M${x} ${300 - i * 4} l18 70 h-36z M${x} ${270 - i * 4} l14 40 h-28z`} fill="#2f4f3a" />
      ))}
    </g>
  );
}

export function Lantern({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M0 -40 v20" stroke={ink} strokeWidth="1.5" />
      <ellipse cx="0" cy="0" rx="16" ry="22" fill="#c4473a" stroke={ink} strokeWidth="1.6" />
      <ellipse cx="0" cy="0" rx="8" ry="12" fill="#e0b15a" opacity="0.7" />
      <path d="M-16 0 h32 M0 -22 v44" stroke="#e0b15a" strokeWidth="1" opacity="0.6" />
    </g>
  );
}

export function PalaceRoof() {
  return (
    <g opacity="0.4">
      <path d="M40 120 q80 -28 120 0 q-20 8 -40 6 q-20 10 -40 4 q-20 8 -40 0z" fill="#3e4a3a" />
      <path d="M520 90 q100 -30 150 0 q-30 10 -50 6 q-24 12 -50 4 q-24 10 -50 0z" fill="#3e4a3a" />
    </g>
  );
}

export function Marigolds() {
  return (
    <g>
      <path d="M60 70 q160 30 320 0 q160 -20 300 16" fill="none" stroke="#2f4a2c" strokeWidth="2" />
      {Array.from({ length: 9 }).map((_, i) => (
        <circle key={i} cx={90 + i * 72} cy={78 + (i % 2) * 8} r="7" fill="#e0a04a" stroke={ink} strokeWidth="1" />
      ))}
    </g>
  );
}

export function GreekBorder() {
  const bits = Array.from({ length: 16 }, (_, i) => i);
  return (
    <g fill="none" stroke="#2f4f6a" strokeWidth="2" opacity="0.55">
      <rect x="28" y="24" width="744" height="452" rx="8" />
      {bits.map((i) => (
        <path key={i} d={`M${48 + i * 44} 40 h16 v10 h-8 v-5`} />
      ))}
    </g>
  );
}

export function Star({
  x,
  y,
  r = 18,
  fill = "#f6e7a8",
  delay = 0,
}: {
  x: number;
  y: number;
  r?: number;
  fill?: string;
  delay?: number;
}) {
  const pts = Array.from({ length: 10 }, (_, i) => {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? r : r * 0.42;
    return `${x + Math.cos(a) * rad},${y + Math.sin(a) * rad}`;
  }).join(" ");
  return (
    <polygon
      points={pts}
      fill={fill}
      stroke="#e0b15a"
      strokeWidth="1"
      className="star-tw"
      style={{ animationDelay: `${delay}s` }}
    />
  );
}

export function Angel({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-70 0 L0 -70 L16 -8" fill="none" stroke="#c9844a" strokeWidth="3" strokeDasharray="5 6" />
      <path d="M-54 -70 q-20 20 0 36 q-28 4 -20 24 q20 -8 28 -2" fill="#f7f7f4" stroke={ink} strokeWidth="1.8" />
      <path d="M54 -70 q20 20 0 36 q28 4 20 24 q-20 -8 -28 -2" fill="#f7f7f4" stroke={ink} strokeWidth="1.8" />
      <path d="M-22 -8 q0 40 22 52 q22 -12 22 -52 q-22 10 -44 0z" fill="#f4efe6" stroke={ink} strokeWidth="2" />
      <circle cx="0" cy="-28" r="14" fill="#f0c7a4" stroke={ink} strokeWidth="1.8" />
      <circle cx="-4" cy="-30" r="1.3" fill={ink} />
      <circle cx="5" cy="-30" r="1.3" fill={ink} />
      <path d="M-4 -22 q4 4 9 0" fill="none" stroke={ink} strokeWidth="1.2" />
      <ellipse cx="-10" cy="-24" rx="3" ry="1.6" fill="#e7a0a0" opacity="0.7" />
      <ellipse cx="0" cy="-48" rx="16" ry="5" fill="none" stroke="#e0b15a" strokeWidth="2.4" />
      <path d="M-8 -20 q-2 8 4 6" fill="none" stroke="#e0b15a" strokeWidth="1.4" />
    </g>
  );
}

export function Gent({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <circle cx="78" cy="-70" r="78" fill="none" stroke="#2f6f86" strokeWidth="3" />
      <circle cx="78" cy="-70" r="3" fill="#2f6f86" />
      <path d="M20 -150 l8 8" stroke="#e0b15a" strokeWidth="3" strokeLinecap="round" />
      <circle cx="8" cy="-118" r="13" fill="#c4844a" stroke={ink} strokeWidth="1.8" />
      <path d="M-2 -128 q10 -12 22 -2 q-8 2 -12 8" fill="#5c3a2a" />
      <circle cx="12" cy="-118" r="1.2" fill={ink} />
      <path d="M4 -112 q6 3 10 0" fill="none" stroke={ink} strokeWidth="1.1" />
      <path d="M-8 -108 q4 16 16 8 l8 46 h22 l6 -30 q-8 -10 -20 -8 q-6 8 -10 0z" fill="#f7f3ea" stroke={ink} strokeWidth="1.8" />
      <path d="M2 -100 h18" stroke="#2f5f8a" strokeWidth="6" strokeLinecap="round" />
      <path d="M8 -54 l-6 54 M28 -50 l10 50" stroke="#355f86" strokeWidth="5" strokeLinecap="round" />
      <path d="M-4 2 h16 M30 2 h16" stroke={ink} strokeWidth="3" />
      <path d="M36 -90 l46 16" stroke="#8d5a32" strokeWidth="3" />
      <circle cx="84" cy="-72" r="4" fill="#e0b15a" stroke={ink} strokeWidth="1" />
      <path d="M-16 -96 q20 -8 28 6" fill="none" stroke={ink} strokeWidth="1.4" />
    </g>
  );
}

export function Log({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="-50" cy="-28" rx="16" ry="22" fill="#c9844a" stroke={ink} strokeWidth="2" />
      <circle cx="-50" cy="-28" r="8" fill="#e8b07a" stroke={ink} strokeWidth="1.2" />
      <rect x="-50" y="-50" width="110" height="44" fill="#a56b3e" stroke={ink} strokeWidth="2.2" />
      <ellipse cx="60" cy="-28" rx="16" ry="22" fill="#c9844a" stroke={ink} strokeWidth="2" />
      <path d="M-20 -40 h60 M-10 -28 h40" stroke="#8d5a32" strokeWidth="1.4" />
    </g>
  );
}

export function Drums({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="-20" rx="36" ry="12" fill="#f4efe6" stroke={ink} strokeWidth="2" />
      <path d="M-36 -20 v28 c0 12 72 12 72 0 v-28" fill="#8d3a32" stroke={ink} strokeWidth="2" />
      <ellipse cx="0" cy="-20" rx="36" ry="12" fill="#f6e7c8" stroke={ink} strokeWidth="2" />
      <path d="M28 -70 q20 -20 10 -4 M40 -78 q16 -16 6 -2" fill="none" stroke={ink} strokeWidth="1.6" />
      <circle cx="46" cy="-86" r="4" fill="none" stroke={ink} strokeWidth="1.4" />
    </g>
  );
}

export function TeaJar({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-40 -20 h80 l-8 -90 h-64z" fill="#f6e2b0" stroke={ink} strokeWidth="2.2" />
      <rect x="-28" y="-118" width="56" height="12" rx="2" fill="#c9844a" stroke={ink} strokeWidth="1.6" />
      <rect x="-22" y="-132" width="44" height="14" rx="3" fill="#8d5a32" stroke={ink} strokeWidth="1.4" />
      <path d="M22 -70 h28 v18 h-20" fill="none" stroke={ink} strokeWidth="2" />
      <rect x="-18" y="-78" width="36" height="22" rx="2" fill="#faf6ee" stroke={ink} strokeWidth="1.2" />
      <text x="0" y="-61" textAnchor="middle" fontFamily="Georgia, serif" fontSize="18" fontWeight="700" fill={ink}>
        IN
      </text>
      <path d="M36 -40 q8 10 0 16" fill="none" stroke="#8d5a32" strokeWidth="1.4" />
    </g>
  );
}

export function Radio({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-90" y="-110" width="180" height="100" rx="16" fill="#c9844a" stroke={ink} strokeWidth="2.3" />
      <rect x="-78" y="-98" width="70" height="54" rx="6" fill="#f6e7c8" stroke={ink} strokeWidth="1.5" />
      <circle cx="40" cy="-70" r="28" fill="#1c2744" stroke={ink} strokeWidth="2" />
      <circle cx="40" cy="-70" r="20" fill="none" stroke="#e0b15a" strokeWidth="1.2" />
      <path d="M40 -70 h20" stroke="#e0b15a" strokeWidth="2.4" />
      <circle cx="40" cy="-70" r="3" fill="#e0b15a" />
      <circle cx="-50" cy="-40" r="5" fill="#e0b15a" stroke={ink} strokeWidth="1" />
      <path d="M70 -110 q30 -40 8 -8" fill="none" stroke={ink} strokeWidth="3" strokeLinecap="round" />
      <path d="M-20 -20 h40" stroke={ink} strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

export function SquareVeg({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-8 -150 q-20 -20 8 -8 q16 -24 10 4 q20 -8 4 16" fill="#3f6b45" stroke={ink} strokeWidth="1.6" />
      <rect x="-46" y="-130" width="92" height="92" rx="10" fill="#e07a3a" stroke={ink} strokeWidth="2.3" />
      <path d="M-30 -40 c8 30 16 50 20 70 M0 -40 c4 28 2 50 0 74 M24 -40 c-4 24 -8 48 -6 68" fill="none" stroke="#c96a32" strokeWidth="2" />
      <path d="M-6 -20 c0 40 8 60 6 78" fill="none" stroke="#8d5a32" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

export function Signpost({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-6" y="-120" width="12" height="120" fill="#8d5a32" stroke={ink} strokeWidth="1.8" />
      <rect x="-70" y="-150" width="140" height="64" rx="6" fill="#f6f1e6" stroke={ink} strokeWidth="2.2" />
      <path d="M-50 -118 q20 -16 40 0 q20 16 40 0 q-20 14 -40 0 q-20 -14 -40 0" fill="none" stroke="#2f6f86" strokeWidth="3" />
    </g>
  );
}

export function Rabbit({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="-16" rx="12" ry="10" fill="#f7f3ea" stroke={ink} strokeWidth="1.5" />
      <ellipse cx="8" cy="-24" rx="7" ry="6" fill="#f7f3ea" stroke={ink} strokeWidth="1.4" />
      <path d="M4 -28 l-2 -14 M10 -30 l4 -12" stroke={ink} strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="10" cy="-25" r="1" fill={ink} />
      <ellipse cx="-10" cy="-10" rx="4" ry="3" fill="#f7f3ea" stroke={ink} strokeWidth="1" />
    </g>
  );
}

export function Apple({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M4 -70 q16 -20 -2 -8" fill="none" stroke="#6d4424" strokeWidth="2" />
      <path d="M8 -64 q16 -8 10 6" fill="#3f6b45" stroke={ink} strokeWidth="1" />
      <circle cx="0" cy="-36" r="28" fill="#c4473a" stroke={ink} strokeWidth="2.2" />
      <ellipse cx="-8" cy="-46" rx="6" ry="4" fill="#fff" opacity="0.25" />
    </g>
  );
}

export function Newt({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-20 -8 q20 -16 40 -2 q8 8 -4 10 q-20 4 -36 -8z" fill="#d46a32" stroke={ink} strokeWidth="1.6" />
      <circle cx="16" cy="-10" r="1.1" fill={ink} />
      <path d="M-16 -6 l-8 6 M-4 -2 l-4 8 M8 -2 l4 8" stroke="#d46a32" strokeWidth="1.5" />
      <path d="M-22 -6 q-10 -8 -4 2" fill="none" stroke="#e08a48" strokeWidth="2" />
    </g>
  );
}

export function Jewel({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="36" rx="54" ry="12" fill="#5c3048" />
      <path d="M-36 10 l18 -40 h36 l18 40 l-36 28z" fill="#9b2d3a" stroke={ink} strokeWidth="2" />
      <path d="M-18 -30 l18 40 l18 -40" fill="#c4473a" stroke={ink} strokeWidth="1.2" />
      <path d="M-28 -10 l16 -8" stroke="#fff" strokeWidth="2" opacity="0.5" />
    </g>
  );
}

export function QuestionBulb({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="8" rx="70" ry="28" fill="#e0b15a" opacity="0.25" />
      <circle cx="0" cy="-40" r="46" fill="#f6e7a8" stroke={ink} strokeWidth="2.2" />
      <rect x="-16" y="4" width="32" height="16" rx="2" fill="#c9b8a0" stroke={ink} strokeWidth="1.6" />
      <path d="M-10 -28 q0 -28 16 -28 q18 0 18 16 q0 14 -12 18 v8 h-12 v-10 q10 -4 10 -14 q0 -8 -8 -8 q-8 0 -8 10" fill="none" stroke={ink} strokeWidth="3" strokeLinecap="round" />
      <circle cx="2" cy="-6" r="2.4" fill={ink} />
    </g>
  );
}

export function Ant({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="-16" cy="-10" rx="12" ry="8" fill="#2b241c" />
      <ellipse cx="2" cy="-12" rx="10" ry="8" fill="#2b241c" />
      <circle cx="16" cy="-16" r="7" fill="#2b241c" />
      <circle cx="18" cy="-18" r="1.2" fill="#f6e7a8" />
      <path d="M12 -20 l-8 -10 M20 -20 l8 -8" stroke={ink} strokeWidth="1.3" />
      <path d="M-8 -8 l-10 10 M2 -6 l8 12 M-16 -4 l-12 8" stroke={ink} strokeWidth="1.4" />
    </g>
  );
}

export function Pear({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M0 -78 q8 -16 -2 -4" stroke="#5c3a22" strokeWidth="2" />
      <path d="M4 -70 q12 -6 6 6" fill="#3f6b45" />
      <path d="M0 -20 c-28 0 -36 -30 -22 -48 c10 -18 40 -22 48 -4 c10 20 -4 52 -26 52z" fill="#c6d36a" stroke={ink} strokeWidth="2.1" />
      <ellipse cx="-8" cy="-40" rx="5" ry="3" fill="#fff" opacity="0.3" />
    </g>
  );
}

export function Cat({ x = 0, y = 0, s = 1, tone = "#e0a04a" }: Place & { tone?: string }) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="-28" cy="-8" rx="16" ry="10" fill={tone} stroke={ink} strokeWidth="1.6" />
      <ellipse cx="0" cy="-28" rx="28" ry="20" fill={tone} stroke={ink} strokeWidth="2" />
      <circle cx="24" cy="-48" r="14" fill={tone} stroke={ink} strokeWidth="1.8" />
      <path d="M14 -58 l-4 -16 l12 8 M28 -60 l10 -12 l-2 16" fill={tone} stroke={ink} strokeWidth="1.5" />
      <circle cx="20" cy="-50" r="1.4" fill={ink} />
      <circle cx="28" cy="-50" r="1.4" fill={ink} />
      <path d="M22 -44 q4 3 8 0" fill="none" stroke={ink} strokeWidth="1" />
      <path d="M-8 -16 v16 M8 -14 v16" stroke={tone} strokeWidth="4" />
    </g>
  );
}

export function Clipboard({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-28" y="-90" width="56" height="78" rx="4" fill="#faf6ee" stroke={ink} strokeWidth="2" />
      <rect x="-12" y="-98" width="24" height="12" rx="3" fill="#c9b8a0" stroke={ink} strokeWidth="1.3" />
      {[0, 1, 2, 3].map((i) => (
        <g key={i}>
          <circle cx="-16" cy={-70 + i * 14} r="3" fill="none" stroke="#2f7d78" strokeWidth="1.3" />
          <path d={`M-18 ${-69 + i * 14} l2 2 l4 -4`} fill="none" stroke="#2f7d78" strokeWidth="1.2" />
          <path d={`M-8 ${-70 + i * 14} h22`} stroke={ink} strokeWidth="1.2" opacity="0.4" />
        </g>
      ))}
    </g>
  );
}

export function Onion({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M0 -78 q8 -16 2 -6 q10 -18 4 4" fill="#6d8f4e" stroke={ink} strokeWidth="1.2" />
      <ellipse cx="0" cy="-36" rx="32" ry="36" fill="#f3e2b8" stroke={ink} strokeWidth="2.2" />
      <path d="M-18 -40 q18 8 36 -6 M-14 -20 q16 10 32 0" fill="none" stroke="#e0c48a" strokeWidth="1.5" />
      <ellipse cx="-8" cy="-48" rx="6" ry="4" fill="#fff" opacity="0.35" />
    </g>
  );
}

export function MinusBadge({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <circle r="22" fill="#f6f1e6" stroke={ink} strokeWidth="2" />
      <path d="M-10 0 h20" stroke="#8d3a32" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}

export function PlusBadge({ x, y }: { x: number; y: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <circle r="16" fill="#f6e7a8" stroke={ink} strokeWidth="1.8" />
      <path d="M-7 0 h14 M0 -7 v14" stroke="#8d3a32" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
}

export function Parrot({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-10 -10 q-30 -20 -10 -40 q8 10 16 8" fill="#2f7d78" stroke={ink} strokeWidth="1.6" />
      <ellipse cx="10" cy="-40" rx="22" ry="28" fill="#3f9a86" stroke={ink} strokeWidth="2" />
      <circle cx="22" cy="-62" r="12" fill="#3f9a86" stroke={ink} strokeWidth="1.8" />
      <path d="M30 -64 l16 4 l-14 6z" fill="#e0a04a" stroke={ink} strokeWidth="1.3" />
      <circle cx="24" cy="-64" r="1.5" fill={ink} />
      <path d="M4 -20 q16 20 8 28 q-20 -4 -16 -20" fill="#c4473a" stroke={ink} strokeWidth="1.4" />
      <path d="M0 -8 v16 M12 -6 v16" stroke="#e0a04a" strokeWidth="2.4" />
    </g>
  );
}

export function Mermaid({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-8 -10 c20 30 10 70 -20 78 c28 4 48 -20 40 -58 c-4 -20 -8 -28 -20 -20z" fill="#2f7d78" stroke={ink} strokeWidth="2" />
      <path d="M-28 62 l16 16 l20 -18" fill="#3e948e" stroke={ink} strokeWidth="1.6" />
      <path d="M-16 -10 q-4 28 10 36 q18 -8 12 -36z" fill="#f0c7a4" stroke={ink} strokeWidth="1.8" />
      <circle cx="0" cy="-28" r="12" fill="#f0c7a4" stroke={ink} strokeWidth="1.7" />
      <path d="M-12 -30 q2 -24 20 -16 q-8 4 -10 16" fill="#5c3a22" />
      <circle cx="3" cy="-29" r="1.2" fill={ink} />
      <path d="M-2 -22 q4 3 8 0" fill="none" stroke={ink} strokeWidth="1" />
      <path d="M-4 -4 q-16 6 -8 16" fill="none" stroke="#f0c7a4" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}

export function Broom({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M0 -160 v120" stroke="#8d5a32" strokeWidth="5" strokeLinecap="round" />
      <path d="M-22 -20 h44 l-6 36 h-32z" fill="#c9844a" stroke={ink} strokeWidth="1.8" />
      {[-14, -6, 2, 10].map((dx) => (
        <path key={dx} d={`M${dx} -8 v28`} stroke="#a56b3e" strokeWidth="1.4" />
      ))}
    </g>
  );
}

export function Mine({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-90 0 q40 -80 90 -90 q50 10 90 90z" fill="#6d645b" stroke={ink} strokeWidth="2" />
      <path d="M-28 -8 v-36 h56 v36" fill="#3a342c" stroke={ink} strokeWidth="2" />
      <path d="M-28 -44 h56" stroke="#8d5a32" strokeWidth="4" />
      <path d="M-18 -20 l8 8 l8 -10 l8 12 l8 -8" fill="none" stroke="#e0b15a" strokeWidth="1.4" />
      <ellipse cx="40" cy="-6" rx="22" ry="6" fill="#6d2e2a" opacity="0.8" />
    </g>
  );
}

export function GinBottle({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-8" y="-150" width="16" height="28" fill="#d7ebe4" stroke={ink} strokeWidth="1.6" />
      <path d="M-26 -122 h52 l8 100 h-68z" fill="#e7f3ef" stroke={ink} strokeWidth="2.2" />
      <rect x="-16" y="-90" width="32" height="36" rx="2" fill="#faf6ee" stroke={ink} strokeWidth="1" />
      <circle cx="-4" cy="-76" r="4" fill="#3f6b45" />
      <circle cx="6" cy="-68" r="3.5" fill="#2f4a2c" />
      <path d="M-2 -84 q8 6 10 2" fill="none" stroke="#3f6b45" strokeWidth="1.2" />
    </g>
  );
}

export function Halo({ x, y }: { x: number; y: number }) {
  return <ellipse cx={x} cy={y} rx="28" ry="10" fill="none" stroke="#e0b15a" strokeWidth="4" />;
}

export function Bun({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="-16" rx="40" ry="16" fill="#e8b07a" stroke={ink} strokeWidth="2" />
      <path d="M-40 -16 c0 -28 80 -28 80 0" fill="#f2d2a4" stroke={ink} strokeWidth="2" />
      <path d="M-16 -28 q4 -8 2 -2 M6 -32 q6 -8 1 -1" stroke="#fff" strokeWidth="1.5" opacity="0.7" />
    </g>
  );
}

export function Coal({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-16 -8 l10 -18 l18 6 l8 16 l-14 10 l-18 -4z" fill="#2b241c" stroke="#1c1915" strokeWidth="1.4" />
      <path d="M-4 -16 l6 6" stroke="#5c5346" strokeWidth="1.4" />
    </g>
  );
}

export function Jeans({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-70 -20 h140" stroke="#8d5a32" strokeWidth="3" />
      <path d="M-46 -20 v-8 M46 -20 v-8" stroke="#c9b8a0" strokeWidth="2" />
      <path d="M-40 -120 h80 v46 l-8 74 h-24 l-8 -40 l-8 40 h-24 l-8 -74z" fill="#355f86" stroke={ink} strokeWidth="2.2" />
      <path d="M-20 -100 h16 v14 h-16z" fill="#e0b15a" stroke={ink} strokeWidth="1.2" />
      <path d="M-16 -96 q4 4 8 -2 q4 6 8 -2" fill="none" stroke="#f6f1e6" strokeWidth="1" />
      <path d="M-28 -70 h20 M8 -70 h18" stroke="#e0b15a" strokeWidth="2" />
      <circle cx="-8" cy="-48" r="3" fill="#e0b15a" />
    </g>
  );
}

export function Stag({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="-10" cy="-48" rx="58" ry="28" fill="#c4a882" stroke={ink} strokeWidth="2.2" />
      <path d="M30 -70 c20 -10 40 -6 48 8 c-16 2 -28 10 -36 18" fill="#c4a882" stroke={ink} strokeWidth="2" />
      <path d="M40 -78 l-4 -22 M48 -80 l6 -20 M36 -74 l-12 -16 M52 -76 l14 -12" fill="none" stroke="#8d5a32" strokeWidth="2.4" strokeLinecap="round" />
      <circle cx="62" cy="-62" r="2" fill={ink} />
      <ellipse cx="78" cy="-56" rx="8" ry="5" fill="#2b241c" />
      <path d="M-40 -30 v28 M-16 -26 v26 M20 -26 v26 M40 -30 v28" stroke="#8d5a32" strokeWidth="4" strokeLinecap="round" />
      <path d="M-4 -48 l8 10 l8 -10 l8 12 l-8 8 l-10 -6z" fill="#c4473a" stroke={ink} strokeWidth="1" />
      <path d="M-62 -40 c-12 8 -8 18 0 16" fill="#efe6d4" stroke={ink} strokeWidth="1.4" />
    </g>
  );
}

export function Child({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-8 -8 l18 4" stroke="#e0b15a" strokeWidth="6" strokeLinecap="round" />
      <circle cx="16" cy="-4" r="14" fill="none" stroke="#c4473a" strokeWidth="2" strokeDasharray="3 3" />
      <path d="M-6 -20 v-28" stroke="#3d6f9a" strokeWidth="8" strokeLinecap="round" />
      <path d="M-16 -8 l-8 8 M6 -16 l16 -2" stroke="#3d6f9a" strokeWidth="5" strokeLinecap="round" />
      <circle cx="-6" cy="-62" r="13" fill="#c4845a" stroke={ink} strokeWidth="1.8" />
      <path d="M-16 -66 q6 -16 20 -4 q-6 2 -10 8" fill="#2b241c" />
      <circle cx="-2" cy="-63" r="1.2" fill={ink} />
      <path d="M-18 -40 q8 8 22 2 l4 20 h-28z" fill="#f2d2a4" stroke={ink} strokeWidth="1.6" />
      <path d="M8 -28 l22 8" stroke="#c4845a" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}

export function Habit({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M0 -150 v20" stroke="#8d5a32" strokeWidth="3" />
      <path d="M-36 -128 q36 -20 72 0 l8 110 h-88z" fill="#6d4424" stroke={ink} strokeWidth="2.2" />
      <path d="M-8 -120 q20 16 40 0 v28 q-20 12 -40 0z" fill="#5c3a22" stroke={ink} strokeWidth="1.5" />
      <path d="M4 -108 q8 8 16 2" fill="none" stroke="#3a342c" strokeWidth="1.4" />
    </g>
  );
}

export function Bat({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="0" cy="0" rx="8" ry="7" fill="#3a342c" stroke={ink} strokeWidth="1.2" />
      <path d="M-6 -2 q-20 -16 -28 2 q12 6 28 2 M6 -2 q20 -16 28 2 q-12 6 -28 2" fill="#4a4038" stroke={ink} strokeWidth="1.2" />
      <circle cx="-3" cy="-1" r="1" fill="#f6e7a8" />
      <circle cx="3" cy="-1" r="1" fill="#f6e7a8" />
    </g>
  );
}

export function Shield({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-28 -36 h56 v28 c0 28 -28 40 -28 40 s-28 -12 -28 -40z" fill="#f6f1e6" stroke={ink} strokeWidth="2" />
      <path d="M-8 -8 q8 10 16 0" fill="none" stroke="#2f7d78" strokeWidth="2" />
      <circle cx="0" cy="-16" r="4" fill="#e0b15a" />
    </g>
  );
}

export function Gus({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-8 -150 l8 -16 l8 16" fill="#c4473a" stroke={ink} strokeWidth="1.4" />
      <ellipse cx="0" cy="-118" rx="46" ry="22" fill="#c4473a" stroke={ink} strokeWidth="2.2" />
      <rect x="-16" y="-100" width="32" height="70" rx="10" fill="#f6f1e6" stroke={ink} strokeWidth="2" />
      <circle cx="-6" cy="-78" r="2" fill={ink} />
      <circle cx="7" cy="-78" r="2" fill={ink} />
      <path d="M-5 -68 q5 5 11 0" fill="none" stroke={ink} strokeWidth="1.4" />
      <rect x="-22" y="-58" width="44" height="16" rx="2" fill="#faf6ee" stroke={ink} strokeWidth="1" />
      <text x="0" y="-46" textAnchor="middle" fontFamily="Georgia, serif" fontSize="13" fontWeight="700" fill={ink}>
        Gus
      </text>
      <circle cx="-40" cy="-140" r="3" fill="#e0b15a" />
      <circle cx="36" cy="-150" r="2.5" fill="#2f7d78" />
      <circle cx="48" cy="-120" r="2" fill="#c4473a" />
    </g>
  );
}

export function Vacuum({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <ellipse cx="-10" cy="-20" rx="46" ry="28" fill="#c4473a" stroke={ink} strokeWidth="2.2" />
      <rect x="-46" y="-36" width="28" height="22" rx="4" fill="#8d3a32" stroke={ink} strokeWidth="1.5" />
      <path d="M28 -30 q40 -10 48 -36" fill="none" stroke="#8d5a32" strokeWidth="5" />
      <path d="M74 -70 q20 8 8 20 q-16 4 -22 -6" fill="#d9d3c8" stroke={ink} strokeWidth="1.6" />
      <circle cx="-16" cy="-8" r="10" fill={ink} />
      <circle cx="16" cy="-6" r="10" fill={ink} />
      <circle cx="-16" cy="-8" r="4" fill="#ccc" />
      <circle cx="16" cy="-6" r="4" fill="#ccc" />
    </g>
  );
}

export function Church({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-70 -20 h140 v-70 h-140z" fill="#e7dcc8" stroke={ink} strokeWidth="2.2" />
      <path d="M-78 -90 h156 l-78 -48z" fill="#8d5a32" stroke={ink} strokeWidth="2" />
      <rect x="-10" y="-168" width="20" height="40" fill="#e7dcc8" stroke={ink} strokeWidth="1.6" />
      <path d="M0 -184 v22 M-8 -174 h16" stroke={ink} strokeWidth="2" />
      <path d="M-16 -20 v-36 h32 v36" fill="#5c3a22" stroke={ink} strokeWidth="1.5" />
      <path d="M-16 -56 a16 16 0 0 1 32 0" fill="#6d4424" />
      <rect x="-58" y="-62" width="16" height="22" fill="#c5e4ef" stroke={ink} strokeWidth="1.2" />
      <rect x="42" y="-62" width="16" height="22" fill="#c5e4ef" stroke={ink} strokeWidth="1.2" />
    </g>
  );
}

export function Scale({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <rect x="-70" y="-12" width="140" height="12" rx="3" fill="#d9d3c8" stroke={ink} strokeWidth="1.8" />
      <rect x="-50" y="-18" width="100" height="8" fill="#eee" stroke={ink} strokeWidth="1.2" />
      <circle cx="0" cy="-8" r="4" fill="#8d3a32" />
    </g>
  );
}

export function Salt({ x = 0, y = 0 }: { x: number; y: number }) {
  return (
    <g fill="#f7f7f4" stroke={ink} strokeWidth="0.8">
      <rect x={x} y={y} width="6" height="6" transform={`rotate(20 ${x} ${y})`} />
      <rect x={x + 12} y={y + 4} width="5" height="5" />
      <rect x={x + 6} y={y + 10} width="5" height="5" transform={`rotate(-15 ${x + 6} ${y + 10})`} />
    </g>
  );
}

export function Bag({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <path d="M-40 -20 h80 l-6 -70 h-68z" fill="#e8c9a0" stroke={ink} strokeWidth="2.2" />
      <path d="M-22 -90 q22 -28 44 0" fill="none" stroke={ink} strokeWidth="3" />
      <path d="M-16 -70 h32" stroke="#c9844a" strokeWidth="2" />
    </g>
  );
}

export function Dad({ x = 0, y = 0, s = 1 }: Place) {
  return (
    <g transform={g({ x, y, s })}>
      <circle cx="0" cy="-112" r="16" fill="#e0a878" stroke={ink} strokeWidth="1.8" />
      <path d="M-14 -116 q6 -16 28 -2 q-10 2 -14 10" fill="#5c3a22" />
      <path d="M-8 -104 q8 4 16 0" fill="none" stroke={ink} strokeWidth="1.4" />
      <circle cx="-5" cy="-114" r="1.3" fill={ink} />
      <circle cx="6" cy="-114" r="1.3" fill={ink} />
      <path d="M-6 -108 h12" stroke={ink} strokeWidth="1.5" />
      <path d="M-22 -96 q4 20 22 28 q18 -8 22 -28 l6 70 h-56z" fill="#355f86" stroke={ink} strokeWidth="1.8" />
      <path d="M-8 -78 h16 v10 h-16z" fill="#f6f1e6" />
      <path d="M-10 -40 v40 M10 -40 v40" stroke="#2c4660" strokeWidth="5" strokeLinecap="round" />
      <path d="M-16 2 h14 M6 2 h14" stroke={ink} strokeWidth="3" />
    </g>
  );
}

export function BeadChain({ x1, y1, x2, y2 }: { x1: number; y1: number; x2: number; y2: number }) {
  const beads = Array.from({ length: 8 }, (_, i) => i / 7);
  return (
    <g>
      {beads.map((t, i) => (
        <circle
          key={i}
          cx={x1 + (x2 - x1) * t}
          cy={y1 + (y2 - y1) * t}
          r="5"
          fill={i % 2 ? "#e0b15a" : "#2f7d78"}
          stroke={ink}
          strokeWidth="1"
        />
      ))}
    </g>
  );
}

export function Wire({ y = 300 }: { y?: number }) {
  return <path d={`M40 ${y} H760`} stroke="#b87333" strokeWidth="4" strokeLinecap="round" />;
}

export function Currants({ x = 0, y = 0 }: { x?: number; y?: number }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      {[-18, -6, 8, 18, -10, 4, 0].map((dx, i) => (
        <circle key={i} cx={dx} cy={i > 3 ? 10 : -2} r="8" fill="#4a2040" stroke={ink} strokeWidth="1.2" />
      ))}
      <path d="M0 -16 q8 -14 2 -4" stroke="#3f6b45" strokeWidth="1.5" />
    </g>
  );
}
