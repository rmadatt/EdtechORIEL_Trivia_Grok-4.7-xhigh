import {
  Ant,
  Apple,
  Church,
  Currants,
  Frame,
  Hills,
  Jewel,
  Newt,
  Pear,
  Plus,
  QuestionBulb,
  Scale,
  Star,
  Vacuum,
  Wire,
} from "./kit";

export function NewtonScene() {
  return (
    <Frame id="newton" from="#d7ecf6" to="#e7f0e0">
      <Hills fill="#c9d8b8" y={400} />
      <Apple x={300} y={360} s={1.5} />
      <Newt x={300} y={300} s={1.5} />
      <g transform="translate(520 180)">
        <Apple s={0.7} />
        <path d="M0 10 v40" stroke="#2b241c" strokeWidth="1.4" strokeDasharray="3 4" />
      </g>
    </Frame>
  );
}

export function JouleScene() {
  return (
    <Frame id="joule" from="#3a2430" to="#241820" ground={false}>
      <ellipse cx="400" cy="300" rx="160" ry="40" fill="#e0b15a" opacity="0.08" />
      <Jewel x={400} y={250} s={1.8} />
    </Frame>
  );
}

export function WattScene() {
  return (
    <Frame id="watt" from="#2a241c" to="#3a342c" ground={false}>
      <ellipse cx="400" cy="280" rx="120" ry="80" fill="#e0b15a" opacity="0.18" />
      <QuestionBulb x={400} y={280} s={1.35} />
    </Frame>
  );
}

export function CurrentScene() {
  return (
    <Frame id="current" from="#f6f1e6" to="#e7eef2">
      <Wire y={280} />
      <Currants x={400} y={268} />
      <path d="M140 250 l18 8 l-18 8" fill="none" stroke="#b87333" strokeWidth="2" />
      <path d="M620 250 l18 8 l-18 8" fill="none" stroke="#b87333" strokeWidth="2" />
      {[180, 260, 540, 640].map((x, i) => (
        <circle key={x} cx={x} cy={280} r="3" fill="#e0b15a" opacity={0.4 + (i % 2) * 0.4} />
      ))}
    </Frame>
  );
}

export function AmpereScene() {
  return (
    <Frame id="ampere" from="#f6f1e6" to="#e7eef2">
      <Wire y={340} />
      <Ant x={300} y={330} s={1.8} />
      <Plus x={420} y={240} />
      <Pear x={540} y={340} s={1.35} />
    </Frame>
  );
}

export function RelativityScene() {
  return (
    <Frame id="relativity" from="#f6e6d4" to="#e7d3c0">
      <rect x="520" y="48" width="230" height="150" rx="4" fill="#1c2744" />
      <Star x={580} y={90} r={7} />
      <Star x={660} y={70} r={5} />
      <Star x={700} y={120} r={4} />
      <rect x="590" y="150" width="90" height="28" rx="4" fill="#c4473a" />
      <circle cx="608" cy="178" r="6" fill="#2b241c" />
      <circle cx="662" cy="178" r="6" fill="#2b241c" />
      <ellipse cx="250" cy="390" rx="150" ry="18" fill="#8d5a32" />
      <path d="M200 330 h50 l-6 -36 h-28z" fill="#f7f3ea" stroke="#2b241c" strokeWidth="1.8" />
      <path d="M214 300 q8 -18 -2 -6" fill="none" stroke="#fff" strokeWidth="2" opacity="0.8" />
      <path d="M188 318 h8" stroke="#2b241c" strokeWidth="3" />
      <g transform="translate(150 400) scale(1.15)">
        <circle cx="0" cy="-78" r="14" fill="#e6c2a4" stroke="#2b241c" strokeWidth="1.6" />
        <path d="M-12 -86 q8 -14 24 0" fill="#c9c2b8" />
        <path d="M-18 -64 h36 l6 48 h-48z" fill="#5c3048" stroke="#2b241c" strokeWidth="1.6" />
        <circle cx="-4" cy="-80" r="1.2" fill="#2b241c" />
        <circle cx="5" cy="-80" r="1.2" fill="#2b241c" />
      </g>
      <g transform="translate(330 410) scale(1.05)">
        <circle cx="0" cy="-58" r="12" fill="#c4845a" stroke="#2b241c" strokeWidth="1.5" />
        <path d="M-8 -66 q6 -12 16 0" fill="#2b241c" />
        <path d="M-14 -46 h28 l4 36 h-36z" fill="#355f86" stroke="#2b241c" strokeWidth="1.5" />
        <circle cx="4" cy="-58" r="1.2" fill="#2b241c" />
      </g>
      <g transform="translate(620 280)">
        <circle r="26" fill="#f6f1e6" stroke="#2b241c" strokeWidth="1.8" />
        <path d="M0 -12 v12 l8 6" fill="none" stroke="#2b241c" strokeWidth="1.7" strokeLinecap="round" />
        <circle cy="-16" r="1.4" fill="#c4473a" />
      </g>
    </Frame>
  );
}

export function DensityScene() {
  return (
    <Frame id="density" from="#d5e3ea" to="#e7dcc8">
      <g>
        {[0, 1, 2, 3].map((i) => (
          <g key={i} transform={`translate(${430 + (i % 2) * 70} ${180 + Math.floor(i / 2) * 90})`}>
            <rect width="80" height="100" fill="#c9b8a0" stroke="#2b241c" strokeWidth="1.6" />
            {[0, 1, 2].map((w) => (
              <rect key={w} x={10 + (w % 2) * 30} y={14 + Math.floor(w / 2) * 28} width="18" height="16" fill="#f6e7a8" />
            ))}
          </g>
        ))}
      </g>
      <path d="M40 400 q80 -120 180 -20 q40 -80 80 20 v40 H40z" fill="#8d6a42" stroke="#2b241c" strokeWidth="2" />
      <ellipse cx="150" cy="330" rx="28" ry="32" fill="#3a2a1c" />
      <circle cx="168" cy="300" r="16" fill="#c47a3a" stroke="#2b241c" strokeWidth="1.6" />
      <path d="M156 290 l-6 -12 M176 288 l8 -10" stroke="#c47a3a" strokeWidth="2" />
      <circle cx="164" cy="298" r="1.3" fill="#2b241c" />
      <circle cx="172" cy="298" r="1.3" fill="#2b241c" />
    </Frame>
  );
}

export function VacuumScene() {
  return (
    <Frame id="vacuum" from="#141a2e" to="#1c2744" ground={false}>
      <Star x={80} y={70} r={6} />
      <Star x={180} y={140} r={4} />
      <Star x={640} y={80} r={8} />
      <Star x={700} y={180} r={5} />
      <Star x={120} y={360} r={5} />
      <Star x={680} y={340} r={4} />
      <circle cx="640" cy="300" r="22" fill="#c9844a" opacity="0.8" />
      <Vacuum x={360} y={280} s={1.5} />
    </Frame>
  );
}

export function ConductionScene() {
  return (
    <Frame id="conduction" from="#f3e2cf" to="#e7d3c0">
      <g transform="translate(230 400)">
        <rect x="-28" y="-8" width="56" height="10" fill="#8d5a32" stroke="#2b241c" strokeWidth="1.4" />
        <path d="M-16 -8 v-70 h32 v70" fill="#1c1915" stroke="#2b241c" strokeWidth="1.6" />
        <circle cx="0" cy="-96" r="12" fill="#e6c2a4" stroke="#2b241c" strokeWidth="1.5" />
        <path d="M-10 -104 q8 -10 20 0" fill="#1c1915" />
        <path d="M8 -90 l28 -36" stroke="#8d5a32" strokeWidth="3" />
        <circle cx="40" cy="-128" r="4" fill="#f6f1e6" />
      </g>
      <Plus x={400} y={220} />
      <g transform="translate(560 380)">
        <ellipse cx="0" cy="-10" rx="40" ry="10" fill="#8d5a32" stroke="#2b241c" strokeWidth="1.6" />
        <path d="M-28 -10 v-20 h56 v20" fill="#c9b8a0" stroke="#2b241c" strokeWidth="1.6" />
        <path d="M-4 -30 v-50" stroke="#b7c3c8" strokeWidth="4" />
        <path d="M-16 -70 q6 -10 0 -16 M0 -78 q8 -12 0 -18 M12 -68 q6 -8 0 -14" stroke="#c4473a" strokeWidth="2" fill="none" />
      </g>
    </Frame>
  );
}

export function MassScene() {
  return (
    <Frame id="mass" from="#e7eef2" to="#e7dcc8">
      <Scale x={400} y={430} s={1.7} />
      <Church x={400} y={400} s={1.15} />
    </Frame>
  );
}
