import {
  Bat,
  Cow,
  Frame,
  Gus,
  Habit,
  Hills,
  Jeans,
  Shield,
  Stag,
  Child,
} from "./kit";

export function GeneScene() {
  return (
    <Frame id="gene" from="#d5eef6" to="#f6f1e6">
      <path d="M80 150 h640" stroke="#8d5a32" strokeWidth="3" />
      <Jeans x={400} y={400} s={1.25} />
      <path d="M354 168 v-16 M446 168 v-16" stroke="#c9b8a0" strokeWidth="2" />
    </Frame>
  );
}

export function DnaScene() {
  const steps = 42;
  const waves = 3.2;
  const colors = ["#e0b15a", "#2f7d78", "#c4473a", "#3f6b45"];
  const pieces: { z: number; d: string; stroke: string; width: number }[] = [];
  for (let i = 0; i < steps; i++) {
    const t0 = i / steps;
    const t1 = (i + 1) / steps;
    const ang0 = t0 * Math.PI * 2 * waves;
    const ang1 = t1 * Math.PI * 2 * waves;
    const x0 = 90 + t0 * 620;
    const x1 = 90 + t1 * 620;
    const a0 = 250 + Math.sin(ang0) * 86;
    const a1 = 250 + Math.sin(ang1) * 86;
    const b0 = 250 - Math.sin(ang0) * 86;
    const b1 = 250 - Math.sin(ang1) * 86;
    const z0 = Math.cos(ang0);
    pieces.push({
      z: z0,
      d: `M${x0} ${a0} L${x1} ${a1}`,
      stroke: z0 > 0 ? "#2b241c" : "#b3a394",
      width: z0 > 0 ? 9 : 5,
    });
    pieces.push({
      z: -z0,
      d: `M${x0} ${b0} L${x1} ${b1}`,
      stroke: z0 < 0 ? "#1f5c56" : "#9fc4bf",
      width: z0 < 0 ? 9 : 5,
    });
    if (i % 3 === 0) {
      pieces.push({
        z: 0,
        d: `M${x0} ${a0} L${x0} ${b0}`,
        stroke: colors[(i / 3) % 4],
        width: 6,
      });
    }
  }
  pieces.sort((p, q) => p.z - q.z);
  return (
    <Frame id="dna" from="#f7f1e6" to="#e7eef2" ground={false}>
      {pieces.map((p, i) => (
        <path key={i} d={p.d} fill="none" stroke={p.stroke} strokeWidth={p.width} strokeLinecap="round" />
      ))}
    </Frame>
  );
}

export function FungusScene() {
  return (
    <Frame id="fungus" from="#2f4a2c" to="#1e3324" ground={false}>
      <ellipse cx="400" cy="420" rx="180" ry="20" fill="#142216" />
      <Gus x={400} y={400} s={1.45} />
      <circle cx="180" cy="120" r="3" fill="#e0b15a" />
      <circle cx="620" cy="90" r="2.5" fill="#f6f1e6" />
      <circle cx="680" cy="180" r="2" fill="#e0a04a" />
    </Frame>
  );
}

export function HeartScene() {
  return (
    <Frame id="heart" from="#e7f2e4" to="#f6ead4">
      <Hills fill="#c9d8b8" y={410} />
      <Stag x={420} y={400} s={1.35} />
    </Frame>
  );
}

export function KidneyScene() {
  return (
    <Frame id="kidney" from="#f6f1e6" to="#e7eef2">
      <rect x="180" y="360" width="80" height="12" rx="3" fill="#c9b8a0" stroke="#2b241c" strokeWidth="1.4" />
      <Child x={250} y={372} s={1.45} />
    </Frame>
  );
}

export function HabitatScene() {
  return (
    <Frame id="habitat" from="#d5d0c8" to="#cfc6ba">
      <path d="M80 460 q160 -220 320 -20 q80 -80 200 20 v40 H80z" fill="#4a4038" opacity="0.35" />
      <Habit x={360} y={400} s={1.25} />
      <Bat x={372} y={268} s={1.3} />
    </Frame>
  );
}

export function VaccineScene() {
  return (
    <Frame id="vaccine" from="#e7f2e4" to="#f6ead4">
      <ellipse cx="400" cy="430" rx="240" ry="18" fill="#b7c9a4" />
      <Cow x={300} y={410} s={1.05} />
      <Shield x={470} y={300} s={1.5} />
      <g transform="translate(560 390)">
        <path d="M-16 -8 h32 l-4 -28 h-24z" fill="#d9d3c8" stroke="#2b241c" strokeWidth="1.5" />
        <ellipse cx="0" cy="-8" rx="16" ry="5" fill="#f6f1e6" stroke="#2b241c" strokeWidth="1.2" />
      </g>
    </Frame>
  );
}

export function MitochondriaScene() {
  return (
    <Frame id="mitochondria" from="#f8e6ea" to="#f6f1e6" ground={false}>
      <ellipse cx="400" cy="250" rx="280" ry="180" fill="#f3d5dc" stroke="#2b241c" strokeWidth="3" />
      <ellipse cx="400" cy="250" rx="250" ry="155" fill="#f8eef0" stroke="#c98a96" strokeWidth="1.5" />
      <g transform="translate(400 250)">
        <ellipse cx="0" cy="10" rx="90" ry="48" fill="#e07a3a" stroke="#2b241c" strokeWidth="2.2" />
        <path
          d="M-70 10 q20 -30 40 0 q20 28 40 0 q20 -24 40 0 q10 16 20 8"
          fill="none"
          stroke="#8d3a32"
          strokeWidth="3"
        />
        <path d="M-40 -8 q16 20 36 0 M0 -6 q14 18 30 0" fill="none" stroke="#f6e7c8" strokeWidth="2" />
        <rect x="70" y="-70" width="28" height="40" fill="#c9b8a0" stroke="#2b241c" strokeWidth="1.4" />
        <path d="M74 -70 v-16 M84 -70 v-22 M94 -70 v-14" stroke="#8d5a32" strokeWidth="2" />
        <path d="M78 -96 q6 -8 0 -4 M88 -100 q8 -10 0 -4" stroke="#e0b15a" strokeWidth="1.6" fill="none" />
      </g>
    </Frame>
  );
}

export function XylemScene() {
  return (
    <Frame id="xylem" from="#e7f2e4" to="#d5e4c8">
      <path d="M300 460 V80 h200 v380z" fill="#e8d7b8" stroke="#2b241c" strokeWidth="2.2" />
      <path d="M330 460 V100 h140 v360" fill="#f6f1e6" stroke="#2b241c" strokeWidth="1.4" />
      {[0, 1, 2, 3, 4].map((i) => (
        <g key={i}>
          <rect x={348 + i * 22} y={180 - i * 8} width="16" height="10" rx="2" fill="#e0b15a" stroke="#2b241c" strokeWidth="1" />
          <path d={`M${356 + i * 22} ${160 - i * 18} q4 -12 0 -8`} fill="none" stroke="#7eb0c9" strokeWidth="1.6" />
        </g>
      ))}
      <path d="M250 200 l90 20" stroke="#8d5a32" strokeWidth="3" />
      <circle cx="250" cy="200" r="8" fill="#f6f1e6" stroke="#2b241c" strokeWidth="1.4" />
      <path d="M520 150 q20 40 0 70" fill="none" stroke="#7eb0c9" strokeWidth="3" strokeLinecap="round" />
    </Frame>
  );
}

export function TissueScene() {
  return (
    <Frame id="tissue" from="#f6f1e6" to="#e7eef2">
      <g transform="translate(400 300)">
        <path d="M-90 40 h180 l-16 -90 h-148z" fill="#f7f7f4" stroke="#2b241c" strokeWidth="2.3" />
        <path d="M-70 -50 q30 -70 70 -10 q20 30 40 -20 l16 20 q-30 50 -70 10 q-24 -20 -56 0z" fill="#faf6ee" stroke="#2b241c" strokeWidth="1.8" />
        {[-20, 0, 20].map((cx) =>
          [-10, 12].map((cy) => (
            <g key={`${cx}-${cy}`}>
              <circle cx={cx} cy={cy - 30} r="7" fill="#f3d5dc" stroke="#2b241c" strokeWidth="1" />
              <circle cx={cx - 2} cy={cy - 32} r="0.8" fill="#2b241c" />
            </g>
          )),
        )}
        <ellipse cx="-40" cy="10" rx="16" ry="8" fill="#e7f0f4" stroke="#9fb0b6" strokeWidth="1" />
      </g>
    </Frame>
  );
}
