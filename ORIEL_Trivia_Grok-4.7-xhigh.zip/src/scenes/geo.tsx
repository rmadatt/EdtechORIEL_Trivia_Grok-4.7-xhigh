import {
  Arch,
  Bridge,
  Car,
  Cooler,
  Cow,
  Deli,
  Don,
  Frame,
  GreekBorder,
  Hen,
  Hills,
  Lantern,
  Marigolds,
  Mosque,
  Mountains,
  PalaceRoof,
  Parthenon,
  Pie,
  Pines,
  Plus,
  Pyramid,
  Rain,
  Rowboat,
  Runner,
  Sink,
  Ski,
  Snow,
  Sole,
  TeaGlass,
  Tie,
  Van,
} from "./kit";

export function MoscowScene() {
  return (
    <Frame id="moscow" from="#d7e6f0" to="#f4efe6">
      <Snow />
      <rect x="36" y="332" width="728" height="108" fill="#8d3a32" />
      {Array.from({ length: 16 }, (_, i) => (
        <rect key={i} x={48 + i * 44} y="316" width="22" height="18" fill="#8d3a32" />
      ))}
      <Mosque x={230} y={430} s={0.92} />
      <Plus x={430} y={230} />
      <Cow x={590} y={432} s={1.05} />
    </Frame>
  );
}

export function AthensScene() {
  return (
    <Frame id="athens" from="#d5eef6" to="#f3e6cf">
      <GreekBorder />
      <path d="M0 430 h800 v70 H0z" fill="#7eb0c9" opacity="0.35" />
      <Parthenon x={660} y={250} s={1.3} />
      <Hills fill="#e7d7b8" y={400} />
      {[
        [150, 250],
        [270, 236],
        [390, 252],
        [510, 240],
        [190, 360],
        [310, 372],
        [430, 356],
        [550, 368],
      ].map(([x, y], i) => (
        <Hen key={i} x={x} y={y} s={0.78} flip={i % 2 === 0} peck={i === 3 || i === 6} />
      ))}
    </Frame>
  );
}

export function HelsinkiScene() {
  return (
    <Frame id="helsinki" from="#e7f1f6" to="#f7f4ee">
      <Pines />
      <Snow />
      <ellipse cx="400" cy="430" rx="320" ry="28" fill="#fff" opacity="0.65" />
      <Hen x={150} y={400} s={1.15} />
      <Plus x={270} y={250} />
      <Sink x={400} y={400} s={1.05} />
      <Plus x={530} y={250} />
      <Ski x={640} y={400} s={0.95} />
    </Frame>
  );
}

export function TaipeiScene() {
  return (
    <Frame id="taipei" from="#f6d7c4" to="#f7f1e6">
      <Lantern x={680} y={90} s={1.4} />
      <Lantern x={120} y={110} s={1} />
      <Tie x={250} y={390} s={1.05} />
      <Plus x={400} y={230} />
      <Pie x={560} y={360} s={1.15} />
    </Frame>
  );
}

export function VancouverScene() {
  return (
    <Frame id="vancouver" from="#d5e3ea" to="#e7eef0">
      <Mountains />
      <Rain />
      <Van x={230} y={400} s={1.05} />
      <Plus x={420} y={250} />
      <Cooler x={580} y={400} s={1.15} />
    </Frame>
  );
}

export function CairoScene() {
  return (
    <Frame id="cairo" from="#f6e2b8" to="#f0d7a4">
      <Pyramid x={140} y={300} s={1.3} />
      <Pyramid x={230} y={320} s={0.8} />
      <path d="M0 430 h800 v40 H0z" fill="#7eb0c9" opacity="0.45" />
      <Car x={250} y={390} s={1} />
      <Plus x={430} y={250} />
      <Rowboat x={590} y={400} s={1.05} />
    </Frame>
  );
}

export function LondonScene() {
  return (
    <Frame id="london" from="#d5e0e8" to="#e5efd8">
      <Bridge />
      <ellipse cx="300" cy="400" rx="220" ry="70" fill="#7ea06a" />
      <g opacity="0.35" stroke="#5e8450" strokeWidth="8">
        <path d="M120 360 q80 20 160 -10" />
        <path d="M140 390 q90 16 180 -8" />
        <path d="M160 420 q70 10 140 -6" />
      </g>
      <Don x={250} y={400} s={1.15} />
      <g transform="translate(620 360) scale(0.7)">
        <rect x="-36" y="-40" width="72" height="40" rx="4" fill="#c4473a" stroke="#2b241c" strokeWidth="2" />
        <rect x="-28" y="-70" width="56" height="30" fill="#c4473a" stroke="#2b241c" strokeWidth="2" />
        <rect x="-20" y="-64" width="14" height="12" fill="#f6e7a8" />
        <rect x="4" y="-64" width="14" height="12" fill="#f6e7a8" />
        <circle cx="-18" cy="2" r="7" fill="#2b241c" />
        <circle cx="18" cy="2" r="7" fill="#2b241c" />
      </g>
    </Frame>
  );
}

export function TehranScene() {
  return (
    <Frame id="tehran" from="#f3d5c8" to="#f6ead4">
      <Arch x={400} y={300} s={2.2} />
      <TeaGlass x={230} y={400} s={1.25} />
      <Plus x={400} y={240} />
      <Runner x={560} y={400} s={1.2} />
    </Frame>
  );
}

export function SeoulScene() {
  return (
    <Frame id="seoul" from="#e6e2ef" to="#f6f1e6">
      <PalaceRoof />
      <Sole x={400} y={300} s={1.15} />
    </Frame>
  );
}

export function DelhiScene() {
  return (
    <Frame id="delhi" from="#f6e2c0" to="#f3e0c0">
      <Arch x={560} y={250} s={1.6} />
      <Marigolds />
      <Deli x={360} y={400} s={1} />
    </Frame>
  );
}

export function BaghdadScene() {
  return (
    <Frame id="baghdad" from="#f6e7cf" to="#f3e0c8">
      <g transform="translate(230 400) scale(1.15)">
        <path d="M-46 -10 h92 l-8 -86 h-76z" fill="#e8c9a0" stroke="#2b241c" strokeWidth="2.3" />
        <path d="M-24 -96 q24 -30 48 0" fill="none" stroke="#2b241c" strokeWidth="3.2" />
      </g>
      <Plus x={400} y={230} />
      <g transform="translate(560 420) scale(1.05)">
        <circle cx="0" cy="-116" r="16" fill="#e0a878" stroke="#2b241c" strokeWidth="1.8" />
        <path d="M-12 -120 q8 -14 26 0 q-8 2 -12 8" fill="#5c3a22" />
        <path d="M-7 -108 q8 4 15 0" stroke="#2b241c" strokeWidth="1.5" fill="none" />
        <circle cx="-5" cy="-118" r="1.3" fill="#2b241c" />
        <circle cx="6" cy="-118" r="1.3" fill="#2b241c" />
        <path d="M-24 -98 q6 22 24 28 q18 -6 24 -28 l4 72 h-56z" fill="#355f86" stroke="#2b241c" strokeWidth="1.8" />
        <path d="M-8 -20 v36 M8 -20 v36" stroke="#2c4660" strokeWidth="5" strokeLinecap="round" />
      </g>
    </Frame>
  );
}
