import {
  BeadChain,
  Broom,
  Bun,
  Car,
  Cat,
  Clipboard,
  Coal,
  Frame,
  GinBottle,
  Halo,
  Hills,
  Mermaid,
  Mine,
  MinusBadge,
  Onion,
  Ox,
  Parrot,
  Plus,
  PlusBadge,
  Salt,
  Sink,
} from "./kit";

export function GoldScene() {
  const cells = Array.from({ length: 18 * 7 }, (_, i) => i);
  return (
    <Frame
      id="gold"
      from="#2a2118"
      to="#4a3824"
      ground={false}
      defs={
        <linearGradient id="gold-metal" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f8e7b8" />
          <stop offset="35%" stopColor="#e0b15a" />
          <stop offset="70%" stopColor="#a97838" />
          <stop offset="100%" stopColor="#f3dc9a" />
        </linearGradient>
      }
    >
      {cells.map((i) => {
        const c = i % 18;
        const r = Math.floor(i / 18);
        return (
          <rect
            key={i}
            x={18 + c * 42}
            y={18 + r * 66}
            width="36"
            height="56"
            rx="3"
            fill="#f6e7c8"
            opacity="0.06"
          />
        );
      })}
      <g filter="url(#gold-none)">
        <rect x="250" y="70" width="300" height="360" rx="16" fill="url(#gold-metal)" stroke="#f8e7b8" strokeWidth="3" />
        <path d="M270 90 h70 l-40 50 z" fill="#fff" opacity="0.28" />
        <text
          x="286"
          y="150"
          fill="#6a4a16"
          fontFamily="Fraunces, Georgia, serif"
          fontSize="54"
          fontWeight="600"
        >
          79
        </text>
        <rect x="330" y="200" width="140" height="110" rx="8" fill="#f8e7b8" opacity="0.28" stroke="#6a4a16" strokeWidth="1.4" />
        <path d="M300 390 h200" stroke="#6a4a16" strokeWidth="1.2" opacity="0.45" />
      </g>
    </Frame>
  );
}

export function CarbonScene() {
  return (
    <Frame id="carbon" from="#f6f1e6" to="#e7dcc8">
      <Car x={230} y={380} s={1.15} />
      <Plus x={420} y={240} />
      <Bun x={560} y={370} s={1.3} />
      <Coal x={640} y={400} s={1.2} />
    </Frame>
  );
}

export function OxygenScene() {
  return (
    <Frame id="oxygen" from="#e7f2e4" to="#f6ead4">
      <Hills fill="#c9d8b8" y={400} />
      <Ox x={250} y={400} s={1.05} />
      <Plus x={450} y={230} />
      <GinBottle x={590} y={400} s={1.15} />
    </Frame>
  );
}

export function ZincScene() {
  return (
    <Frame id="zinc" from="#e7eef2" to="#f7f7f4">
      <rect x="0" y="0" width="800" height="220" fill="#d5e3ea" opacity="0.5" />
      <Sink x={400} y={400} s={1.7} />
      <rect x="80" y="300" width="36" height="48" rx="3" fill="#b7c0c4" stroke="#2b241c" strokeWidth="1.4" />
      <rect x="680" y="280" width="40" height="56" rx="3" fill="#c5ccd0" stroke="#2b241c" strokeWidth="1.4" />
    </Frame>
  );
}

export function CatalystScene() {
  return (
    <Frame id="catalyst" from="#f6f1e6" to="#e7eef2">
      <Cat x={230} y={390} s={1.45} />
      <Plus x={400} y={240} />
      <Clipboard x={540} y={390} s={1.45} />
      <g transform="translate(400 120)" opacity="0.7">
        <circle cx="-30" cy="0" r="12" fill="#7eb0c9" stroke="#2b241c" strokeWidth="1.4" />
        <circle cx="30" cy="0" r="12" fill="#e0b15a" stroke="#2b241c" strokeWidth="1.4" />
        <path d="M-16 0 h32" stroke="#2b241c" strokeWidth="2" />
        <path d="M0 28 v16" stroke="#2f7d78" strokeWidth="2" strokeDasharray="3 3" />
      </g>
    </Frame>
  );
}

export function AnionScene() {
  return (
    <Frame id="anion" from="#f6ead4" to="#f7f1e6">
      <Onion x={340} y={380} s={1.7} />
      <MinusBadge x={520} y={230} />
      <g fill="#2f6f86">
        <circle cx="250" cy="200" r="5" />
        <circle cx="230" cy="240" r="4" />
        <circle cx="470" cy="300" r="4" />
      </g>
    </Frame>
  );
}

export function CationScene() {
  return (
    <Frame id="cation" from="#f6e7cf" to="#f7f1e6">
      <Cat x={360} y={400} s={1.6} tone="#e0a04a" />
      <PlusBadge x={500} y={200} />
    </Frame>
  );
}

export function PolymerScene() {
  return (
    <Frame id="polymer" from="#d5eef6" to="#e7f2e4">
      <path d="M0 390 q200 -40 400 0 t400 0 v110 H0z" fill="#7eb0c9" opacity="0.35" />
      <Parrot x={220} y={360} s={1.35} />
      <Plus x={400} y={200} />
      <Mermaid x={560} y={390} s={1.15} />
      <BeadChain x1={180} y1={150} x2={640} y2={150} />
    </Frame>
  );
}

export function BromineScene() {
  return (
    <Frame id="bromine" from="#e7eef2" to="#e4d3c4">
      <Broom x={230} y={400} s={1.15} />
      <Plus x={400} y={230} />
      <Mine x={560} y={400} s={1.15} />
    </Frame>
  );
}

export function HalogenScene() {
  return (
    <Frame id="halogen" from="#f7f1e6" to="#e7eef2">
      <GinBottle x={400} y={400} s={1.35} />
      <Halo x={400} y={150} />
      <Salt x={300} y={400} />
      <Salt x={460} y={410} />
    </Frame>
  );
}
