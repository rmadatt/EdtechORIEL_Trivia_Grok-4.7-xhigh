import { useEffect, useMemo, useReducer, useRef, useState, type ReactNode, type RefObject } from "react";
import heroUrl from "../public/images/hero.jpg";
import owlUrl from "../public/images/owl.png";
import cabinetUrl from "../public/images/cabinet.jpg";
import {
  dailyPuzzle,
  puzzles,
  puzzlesIn,
  puzzleById,
  wingOf,
  wings,
  type Category,
  type Puzzle,
} from "./data/puzzles";
import { judge, pointsFor, todayKey, yesterdayKey } from "./lib/match";
import { playTone } from "./lib/sound";
import { BaghdadScene, SceneView } from "./scenes";
import { cn } from "./utils/cn";

type Mode = "tour" | "wing" | "daily" | "one" | "review";
type Screen = "home" | "play" | "results" | "almanac";
type Filter = Category | "all" | "open";

type LogItem = { id: string; ok: boolean; points: number; hints: number };

type Session = {
  mode: Mode;
  title: string;
  wingId?: Category;
  ids: string[];
  index: number;
  score: number;
  named: number;
  log: LogItem[];
  hints: number;
  wrongs: number;
  feedback: string | null;
  revealed: boolean;
  lastOk: boolean;
  lastPoints: number;
  shake: number;
  qStart: number;
  streak: number;
};

type State = {
  screen: Screen;
  filter: Filter;
  session: Session | null;
  solved: string[];
  best: Record<string, number>;
  dailySolvedOn: string | null;
  streak: number;
  sound: boolean;
  confirmReset: boolean;
};

type Action =
  | { type: "home" }
  | { type: "almanac" }
  | { type: "filter"; filter: Filter }
  | { type: "sound" }
  | { type: "confirmReset"; on: boolean }
  | { type: "reset" }
  | {
      type: "start";
      mode: Mode;
      title: string;
      ids: string[];
      wingId?: Category;
      revealed?: boolean;
    }
  | { type: "hint" }
  | { type: "guess"; text: string }
  | { type: "giveup" }
  | { type: "next" };

function load(): Pick<State, "solved" | "best" | "dailySolvedOn" | "streak" | "sound"> {
  try {
    const solved = JSON.parse(localStorage.getItem("oriel-solved") || "[]");
    const best = JSON.parse(localStorage.getItem("oriel-best") || "{}");
    return {
      solved: Array.isArray(solved) ? solved.filter((x) => typeof x === "string") : [],
      best: best && typeof best === "object" ? best : {},
      dailySolvedOn: localStorage.getItem("oriel-daily-on"),
      streak: Number(localStorage.getItem("oriel-streak") || "0") || 0,
      sound: localStorage.getItem("oriel-sound") === "1",
    };
  } catch {
    return { solved: [], best: {}, dailySolvedOn: null, streak: 0, sound: false };
  }
}

function shuffle<T>(list: T[]): T[] {
  const next = [...list];
  for (let i = next.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [next[i], next[j]] = [next[j], next[i]];
  }
  return next;
}

function sample<T>(list: T[]): T {
  return list[Math.floor(Math.random() * list.length)];
}

function tourIds(): string[] {
  const ids: string[] = [];
  for (const wing of wings) {
    const pool = puzzlesIn(wing.id);
    const easy = pool.filter((p) => p.difficulty === 1);
    const hard = pool.filter((p) => p.difficulty > 1);
    ids.push(sample(easy).id, sample(hard).id);
  }
  return shuffle(ids);
}

function wingIds(category: Category): string[] {
  const pool = puzzlesIn(category);
  const easy = shuffle(pool.filter((p) => p.difficulty === 1));
  const rest = shuffle(pool.filter((p) => p.difficulty > 1));
  return [...easy, ...rest].map((p) => p.id);
}

function oliveSays(n: number, total: number): string {
  if (n <= 0) return "I have not met you yet. I am pretending this does not matter.";
  if (n < 8) return "A few frames already know your handwriting.";
  if (n < total / 2) return "The cabinet is starting to look lived in.";
  if (n < total) return "I have begun saving you the good chair.";
  return "Every frame is hung. I shall be unbearable about it.";
}

function rankFor(named: number, total: number) {
  if (total <= 1) {
    return named === 1
      ? { title: "Hung and labeled", line: "One frame, named. Olive makes a small, undignified sound of approval." }
      : { title: "Left in the foyer", line: "The costume stays on. You can walk back in whenever you like." };
  }
  const ratio = total === 0 ? 0 : named / total;
  if (named === total && total > 0) {
    return {
      title: "Keeper of the Cabinet",
      line: "Every frame hung. Olive is insufferable with pride, and has earned it.",
    };
  }
  if (ratio >= 0.8) {
    return {
      title: "Fellow of the Oriel",
      line: "The cabinet knows your step. A few frames still have their backs turned.",
    };
  }
  if (ratio >= 0.6) {
    return {
      title: "Curator",
      line: "You can read a costume. The harder puns are learning your name.",
    };
  }
  if (ratio >= 0.4) {
    return {
      title: "Visitor with a good eye",
      line: "Several truths were hiding in plain ink, and you found them.",
    };
  }
  if (ratio >= 0.2) {
    return {
      title: "Dilettante",
      line: "A promising wander. The syllables are where the secrets live.",
    };
  }
  return {
    title: "Still in the foyer",
    line: "The frames are patient. A nudge is cheaper than another wrong name.",
  };
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "home":
      return { ...state, screen: "home", session: null, confirmReset: false };
    case "almanac":
      return { ...state, screen: "almanac", session: null, confirmReset: false };
    case "filter":
      return { ...state, filter: action.filter };
    case "sound":
      return { ...state, sound: !state.sound };
    case "confirmReset":
      return { ...state, confirmReset: action.on };
    case "reset":
      return {
        ...state,
        solved: [],
        best: {},
        dailySolvedOn: null,
        streak: 0,
        confirmReset: false,
      };
    case "start":
      return {
        ...state,
        screen: "play",
        session: {
          mode: action.mode,
          title: action.title,
          wingId: action.wingId,
          ids: action.ids,
          index: 0,
          score: 0,
          named: 0,
          log: [],
          hints: 0,
          wrongs: 0,
          feedback: action.revealed ? "Already hung today. The label is up." : null,
          revealed: Boolean(action.revealed),
          lastOk: Boolean(action.revealed),
          lastPoints: 0,
          shake: 0,
          qStart: Date.now(),
          streak: 0,
        },
      };
    case "hint": {
      if (!state.session || state.session.revealed || state.session.hints >= 3) return state;
      return {
        ...state,
        session: { ...state.session, hints: state.session.hints + 1, feedback: null },
      };
    }
    case "guess": {
      const session = state.session;
      if (!session || session.revealed) return state;
      const puzzle = puzzleById(session.ids[session.index]);
      if (!puzzle) return state;
      const result = judge(action.text, puzzle, puzzles);
      if (result.kind === "empty") {
        return { ...state, session: { ...session, feedback: "A frame needs a name." } };
      }
      if (result.kind === "correct") {
        const seconds = (Date.now() - session.qStart) / 1000;
        const points = pointsFor(session.hints, seconds, session.streak);
        const solved = state.solved.includes(puzzle.id) ? state.solved : [...state.solved, puzzle.id];
        let { streak, dailySolvedOn } = state;
        if (session.mode === "daily" && dailySolvedOn !== todayKey()) {
          streak = dailySolvedOn === yesterdayKey() ? streak + 1 : 1;
          dailySolvedOn = todayKey();
        }
        return {
          ...state,
          solved,
          streak,
          dailySolvedOn,
          session: {
            ...session,
            revealed: true,
            lastOk: true,
            lastPoints: points,
            score: session.score + points,
            named: session.named + 1,
            streak: session.streak + 1,
            feedback: null,
            log: [...session.log, { id: puzzle.id, ok: true, points, hints: session.hints }],
          },
        };
      }
      const message =
        result.kind === "wrong"
          ? session.wrongs >= 1
            ? "Not the name on this frame. A nudge is cheaper than another guess."
            : "Not the name on this frame."
          : result.message;
      return {
        ...state,
        session: {
          ...session,
          wrongs: session.wrongs + (result.kind === "wrong" ? 1 : 0),
          feedback: message,
          shake: session.shake + 1,
        },
      };
    }
    case "giveup": {
      const session = state.session;
      if (!session || session.revealed) return state;
      const id = session.ids[session.index];
      return {
        ...state,
        session: {
          ...session,
          revealed: true,
          lastOk: false,
          lastPoints: 0,
          streak: 0,
          feedback: null,
          log: [...session.log, { id, ok: false, points: 0, hints: session.hints }],
        },
      };
    }
    case "next": {
      const session = state.session;
      if (!session) return state;
      if (session.mode === "review" || session.index + 1 >= session.ids.length) {
        const best = { ...state.best };
        const key =
          session.mode === "wing" ? session.wingId : session.mode === "tour" ? "tour" : null;
        if (key && session.score > (best[key] ?? 0)) best[key] = session.score;
        if (session.mode === "review") {
          return { ...state, screen: "home", session: null };
        }
        return { ...state, screen: "results", best, session };
      }
      return {
        ...state,
        session: {
          ...session,
          index: session.index + 1,
          hints: 0,
          wrongs: 0,
          feedback: null,
          revealed: false,
          lastOk: false,
          lastPoints: 0,
          qStart: Date.now(),
        },
      };
    }
    default:
      return state;
  }
}

function Gilt({
  children,
  label,
  pigment,
  className,
}: {
  children: ReactNode;
  label?: string;
  pigment?: string;
  className?: string;
}) {
  return (
    <div className={cn("gilt", className)}>
      <div className="gilt-inner">
        {label && pigment && (
          <div
            className="absolute left-3 top-3 z-10 rounded-full px-2.5 py-1 text-[10px] tracking-[0.18em] text-[#f6f0e4]"
            style={{ background: pigment }}
          >
            {label}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

function WingMark({ id }: { id: Category }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round" as const };
  return (
    <svg viewBox="0 0 48 48" className="h-8 w-8" aria-hidden>
      {id === "geography" && (
        <>
          <circle cx="24" cy="24" r="14" {...common} />
          <path d="M10 24h28M24 10c4 6 4 22 0 28M24 10c-4 6-4 22 0 28" {...common} />
        </>
      )}
      {id === "math" && (
        <>
          <circle cx="18" cy="30" r="8" {...common} />
          <path d="M26 14h12M32 8v12M14 18l20-8" {...common} />
        </>
      )}
      {id === "physics" && (
        <>
          <circle cx="24" cy="28" r="8" {...common} />
          <path d="M24 8c8 6 8 10 0 12" {...common} />
          <path d="M20 36h8" {...common} />
        </>
      )}
      {id === "chemistry" && (
        <>
          <path d="M18 8h12M20 8v12l-8 16a8 8 0 0 0 14 8l8-16V8" {...common} />
        </>
      )}
      {id === "biology" && (
        <>
          <path d="M24 40V18M24 26c-8-2-10-10-6-14M24 30c8-2 12-10 6-14" {...common} />
        </>
      )}
    </svg>
  );
}

function Confetti() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {Array.from({ length: 26 }, (_, i) => (
        <span
          key={i}
          className="confetti-bit"
          style={{
            left: `${(i * 37) % 100}%`,
            animationDelay: `${(i % 9) * 0.08}s`,
            background: ["#e0b15a", "#7c2f2a", "#2f7d78", "#f6f1e6", "#243f34"][i % 5],
          }}
        />
      ))}
    </div>
  );
}

const featured = ["moscow", "gold", "seven", "fungus", "joule", "cairo"];

export default function App() {
  const saved = useMemo(load, []);
  const [state, dispatch] = useReducer(reducer, {
    screen: "home",
    filter: "all",
    session: null,
    confirmReset: false,
    ...saved,
  });
  const [featuredIndex, setFeaturedIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [exampleOpen, setExampleOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [openResult, setOpenResult] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const revealRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem("oriel-solved", JSON.stringify(state.solved));
    localStorage.setItem("oriel-best", JSON.stringify(state.best));
    localStorage.setItem("oriel-streak", String(state.streak));
    localStorage.setItem("oriel-sound", state.sound ? "1" : "0");
    if (state.dailySolvedOn) localStorage.setItem("oriel-daily-on", state.dailySolvedOn);
    else localStorage.removeItem("oriel-daily-on");
  }, [state.solved, state.best, state.streak, state.sound, state.dailySolvedOn]);

  useEffect(() => {
    if (paused || state.screen !== "home") return;
    const t = window.setInterval(() => setFeaturedIndex((n) => (n + 1) % featured.length), 5600);
    return () => window.clearInterval(t);
  }, [paused, state.screen]);

  const session = state.session;
  const current = session ? puzzleById(session.ids[session.index]) : undefined;

  useEffect(() => {
    if (state.screen === "play" && session && !session.revealed) inputRef.current?.focus();
  }, [state.screen, session?.index, session?.revealed]);

  useEffect(() => {
    if (session?.revealed) revealRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [session?.revealed, session?.index]);

  function tone(kind: "ok" | "no" | "open") {
    if (state.sound) playTone(kind);
  }

  function startTour() {
    tone("open");
    dispatch({ type: "start", mode: "tour", title: "Grand Tour", ids: tourIds() });
  }

  function startWing(category: Category) {
    tone("open");
    const wing = wingOf(category);
    dispatch({
      type: "start",
      mode: "wing",
      title: wing.label,
      wingId: category,
      ids: wingIds(category),
    });
  }

  function startOne(id: string) {
    tone("open");
    const puzzle = puzzleById(id);
    if (!puzzle) return;
    dispatch({
      type: "start",
      mode: "one",
      title: wingOf(puzzle.category).label,
      wingId: puzzle.category,
      ids: [id],
    });
  }

  function startDaily() {
    tone("open");
    const puzzle = dailyPuzzle();
    const already = state.dailySolvedOn === todayKey();
    dispatch({
      type: "start",
      mode: already ? "review" : "daily",
      title: "Today’s frame",
      ids: [puzzle.id],
      revealed: already,
    });
  }

  function submit(text: string) {
    if (!current || !session || session.revealed) return;
    const result = judge(text, current, puzzles);
    if (result.kind === "correct") tone("ok");
    else if (result.kind !== "empty") tone("no");
    dispatch({ type: "guess", text });
  }

  const daily = dailyPuzzle();
  const dailyHung = state.dailySolvedOn === todayKey();
  const specimen = puzzleById(featured[featuredIndex])!;

  return (
    <div className="min-h-screen overflow-x-hidden text-ink">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-ink/10 bg-paper/90 px-4 py-3 backdrop-blur md:px-8">
        <button
          onClick={() => dispatch({ type: "home" })}
          className="font-serif text-2xl tracking-tight text-olive"
        >
          Oriel
        </button>
        <nav className="flex items-center gap-2 text-sm">
          <button
            onClick={() => dispatch({ type: "almanac" })}
            className={cn(
              "rounded-full px-3 py-1.5",
              state.screen === "almanac" ? "bg-olive text-cream" : "hover:bg-ink/5",
            )}
          >
            Almanac
          </button>
          <button
            onClick={() => dispatch({ type: "sound" })}
            className="rounded-full px-3 py-1.5 hover:bg-ink/5"
            aria-pressed={state.sound}
          >
            Sound {state.sound ? "on" : "off"}
          </button>
        </nav>
      </header>

      {state.screen === "home" && (
        <Home
          solved={state.solved}
          best={state.best}
          streak={state.streak}
          dailyHung={dailyHung}
          daily={daily}
          specimen={specimen}
          featuredIndex={featuredIndex}
          onPause={setPaused}
          onFeatured={setFeaturedIndex}
          onTour={startTour}
          onDaily={startDaily}
          onWing={startWing}
          onTry={() => startOne(specimen.id)}
          onAlmanac={() => dispatch({ type: "almanac" })}
          exampleOpen={exampleOpen}
          onExample={() => setExampleOpen((v) => !v)}
        />
      )}

      {state.screen === "play" && session && current && (
        <Play
          session={session}
          puzzle={current}
          inputRef={inputRef}
          revealRef={revealRef}
          onHint={() => dispatch({ type: "hint" })}
          onGiveup={() => dispatch({ type: "giveup" })}
          onNext={() => dispatch({ type: "next" })}
          onSubmit={submit}
          onLeave={() => dispatch({ type: "home" })}
        />
      )}

      {state.screen === "results" && session && (
        <Results
          session={session}
          openId={openResult}
          onOpen={setOpenResult}
          copied={copied}
          onCopy={async () => {
            const named = session.named;
            const total = session.ids.length;
            const rank = rankFor(named, total);
            const text = `Oriel — ${rank.title}. Named ${named} of ${total}. Score ${session.score}.`;
            try {
              await navigator.clipboard.writeText(text);
              setCopied(true);
            } catch {
              setCopied(false);
            }
          }}
          onAgain={() => {
            if (session.mode === "wing" && session.wingId) startWing(session.wingId);
            else if (session.mode === "daily") startDaily();
            else if (session.mode === "one") startOne(session.ids[0]);
            else startTour();
          }}
          onHome={() => dispatch({ type: "home" })}
          perfect={session.named === session.ids.length && session.ids.length > 0}
        />
      )}

      {state.screen === "almanac" && (
        <Almanac
          solved={state.solved}
          filter={state.filter}
          confirmReset={state.confirmReset}
          onFilter={(filter) => dispatch({ type: "filter", filter })}
          onPlay={startOne}
          onResetAsk={(on) => dispatch({ type: "confirmReset", on })}
          onReset={() => dispatch({ type: "reset" })}
        />
      )}
    </div>
  );
}

function Home({
  solved,
  best,
  streak,
  dailyHung,
  daily,
  specimen,
  featuredIndex,
  onPause,
  onFeatured,
  onTour,
  onDaily,
  onWing,
  onTry,
  onAlmanac,
  exampleOpen,
  onExample,
}: {
  solved: string[];
  best: Record<string, number>;
  streak: number;
  dailyHung: boolean;
  daily: Puzzle;
  specimen: Puzzle;
  featuredIndex: number;
  onPause: (v: boolean) => void;
  onFeatured: (n: number) => void;
  onTour: () => void;
  onDaily: () => void;
  onWing: (c: Category) => void;
  onTry: () => void;
  onAlmanac: () => void;
  exampleOpen: boolean;
  onExample: () => void;
}) {
  const wing = wingOf(specimen.category);
  return (
    <main>
      <section className="mx-auto max-w-6xl px-4 pt-4 md:px-8">
        <div className="relative h-[440px] overflow-hidden rounded-[28px] md:h-[540px]">
          <img
            src={heroUrl}
            alt=""
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#101a16]/88 via-[#101a16]/50 to-[#101a16]/10" />
          <div className="relative z-10 flex h-full max-w-xl flex-col justify-end p-6 md:p-12">
            <p className="text-[11px] tracking-[0.32em] text-[#e0b15a]">A CABINET OF GENERAL KNOWLEDGE</p>
            <h1 className="mt-3 font-serif text-5xl leading-[0.92] text-[#f6f0e4] md:text-7xl">
              Look twice.
              <br />
              Say it once.
            </h1>
            <p className="mt-4 max-w-md text-[17px] leading-relaxed text-[#f6f0e4]/85">
              Cartoon frames from geography, mathematics, physics, chemistry, and biology. The answer is wearing a costume.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl items-end gap-10 px-4 py-12 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <div className="flex flex-col items-start gap-1 sm:flex-row sm:items-end">
            <img
              src={owlUrl}
              alt="Olive, a barn owl in a waistcoat, keeper of the Oriel"
              className="owl-mask -ml-3 w-32 shrink-0 sm:w-40"
            />
            <p className="max-w-xs pb-2 font-serif text-xl italic leading-snug text-olive sm:pb-6 sm:text-2xl">
              “{oliveSays(solved.length, puzzles.length)}”
            </p>
          </div>
          <div className="mt-2 flex flex-wrap gap-3">
            <button
              onClick={onTour}
              className="rounded-full bg-olive px-5 py-3 text-sm tracking-wide text-cream transition hover:bg-[#1b3229]"
            >
              Begin the Grand Tour
            </button>
            <button
              onClick={onDaily}
              className="rounded-full border border-ink/15 bg-cream/70 px-5 py-3 text-sm transition hover:border-ink/40"
            >
              {dailyHung ? "Today’s frame is hung" : "Today’s frame"}
            </button>
          </div>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
            Ten frames, two from each wing. A clean naming outscores a hinted one. Spelling may wander a little — Olive is not a pedant.
          </p>
          <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1 text-sm text-ink/70">
            <span>
              Cabinet {solved.length} / {puzzles.length} hung
            </span>
            {best.tour ? <span>Best tour {best.tour}</span> : null}
            {streak > 0 ? (
              <span>
                {streak}-day streak{dailyHung ? "" : " · today’s still open"}
              </span>
            ) : null}
          </div>
          {dailyHung && (
            <p className="mt-3 text-sm text-olive">
              Today Olive hung <span className="font-serif italic">{daily.answer}</span> — {daily.say}.
            </p>
          )}
        </div>

        <div
          className="md:col-span-7"
          onMouseEnter={() => onPause(true)}
          onMouseLeave={() => onPause(false)}
        >
          <div className="mb-3 flex items-end justify-between">
            <p className="text-[11px] tracking-[0.22em] text-gold">A FRAME FROM THE CABINET</p>
            <div className="flex gap-1.5">
              {featured.map((id, i) => (
                <button
                  key={id}
                  aria-label={`Show frame ${i + 1}`}
                  onClick={() => onFeatured(i)}
                  className={cn("h-1.5 rounded-full transition", i === featuredIndex ? "w-6 bg-olive" : "w-1.5 bg-ink/20")}
                />
              ))}
            </div>
          </div>
          <Gilt label={wing.label.toUpperCase()} pigment={wing.pigment}>
            <div className="aspect-[8/5]">
              <SceneView id={specimen.id} />
            </div>
          </Gilt>
          <div className="mt-4 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="font-serif text-2xl">{specimen.prompt}</p>
              <p className="text-sm text-muted">Say what you see. Then say it as one name.</p>
            </div>
            <button
              onClick={onTry}
              className="rounded-full border border-ink/15 px-4 py-2 text-sm hover:border-ink/40"
            >
              Try this frame
            </button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-6 md:px-8">
        <div className="mb-4 flex items-end justify-between gap-4">
          <h2 className="font-serif text-3xl md:text-4xl">The five wings</h2>
          <button onClick={onAlmanac} className="text-sm underline decoration-gold/70 underline-offset-4">
            Open the almanac
          </button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {wings.map((wing) => {
            const total = puzzlesIn(wing.id).length;
            const hung = puzzlesIn(wing.id).filter((p) => solved.includes(p.id)).length;
            return (
              <button
                key={wing.id}
                onClick={() => onWing(wing.id)}
                className="group flex min-h-52 flex-col justify-between rounded-2xl p-4 text-left text-[#f6f0e4] transition hover:-translate-y-0.5"
                style={{ background: wing.pigment }}
              >
                <div>
                  <div className="flex items-center justify-between text-[#f6f0e4]/80">
                    <span className="text-[10px] tracking-[0.22em]">{wing.kicker.toUpperCase()}</span>
                    <WingMark id={wing.id} />
                  </div>
                  <h3 className="mt-3 font-serif text-2xl">{wing.label}</h3>
                  <p className="mt-2 text-sm leading-snug text-[#f6f0e4]/78">{wing.blurb}</p>
                </div>
                <div className="mt-5">
                  <div className="h-1 overflow-hidden rounded-full bg-[#f6f0e4]/20">
                    <div className="h-full bg-gilt" style={{ width: `${(hung / total) * 100}%` }} />
                  </div>
                  <p className="mt-2 text-xs tracking-wide text-[#f6f0e4]/70">
                    {hung} of {total} hung
                    {best[wing.id] ? ` · best ${best[wing.id]}` : ""}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-2 md:px-8">
        <div>
          <p className="text-[11px] tracking-[0.22em] text-gold">HOW A FRAME IS READ</p>
          <h2 className="mt-2 font-serif text-4xl leading-tight">Name the costume. Then name the wearer.</h2>
          <ol className="mt-6 space-y-4 text-[15px] leading-relaxed">
            <li>
              <span className="font-serif text-gold">01 </span>
              Name the objects. A mosque. A cow. A pie. A sink.
            </li>
            <li>
              <span className="font-serif text-gold">02 </span>
              Say them as if they were one word. Mosque-cow. The ear does the last step.
            </li>
            <li>
              <span className="font-serif text-gold">03 </span>
              Trust the plaque. It tells you whether you are after a city, an element, an organ, or a unit.
            </li>
          </ol>
          <div className="mt-6 rounded-2xl border border-ink/10 bg-cream/60 p-4">
            <p className="text-[11px] tracking-[0.18em] text-muted">A WORKED FRAME, NOT IN THE CABINET</p>
            <p className="mt-2 text-sm leading-relaxed">
              A bag beside a dad, asked as a city.
              {exampleOpen ? (
                <span className="font-serif text-lg text-olive"> Baghdad.</span>
              ) : (
                " The naming is one breath away."
              )}
            </p>
            <button onClick={onExample} className="mt-3 text-sm underline decoration-gold underline-offset-4">
              {exampleOpen ? "Cover the label" : "Say it"}
            </button>
          </div>
        </div>
        <div>
          <Gilt>
            <div className="aspect-[8/5] bg-[#f6e7cf]">
              {exampleOpen ? (
                <div className="flex h-full flex-col items-center justify-center px-8 text-center">
                  <p className="text-[11px] tracking-[0.22em] text-gold">THE NAMING</p>
                  <p className="mt-2 font-serif text-5xl text-olive">Baghdad</p>
                  <p className="mt-2 text-sm text-muted">bag + dad</p>
                </div>
              ) : (
                <BaghdadScene />
              )}
            </div>
          </Gilt>
          <div className="mt-4 overflow-hidden rounded-[22px]">
            <img
              src={cabinetUrl}
              alt="A naturalist's desk: olive branch, magnifying glass, empty gilt frame, pine cone, and a glass marble"
              className="aspect-[5/4] w-full object-cover"
            />
          </div>
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-4 pb-12 text-sm text-muted md:px-8">
        Oriel keeps {puzzles.length} frames. None of them are maps. Olive apologizes to cartographers, and to anyone who pronounces Helsinki in a single dignified syllable.
      </footer>
    </main>
  );
}

function Play({
  session,
  puzzle,
  inputRef,
  revealRef,
  onHint,
  onGiveup,
  onNext,
  onSubmit,
  onLeave,
}: {
  session: Session;
  puzzle: Puzzle;
  inputRef: RefObject<HTMLInputElement | null>;
  revealRef: RefObject<HTMLDivElement | null>;
  onHint: () => void;
  onGiveup: () => void;
  onNext: () => void;
  onSubmit: (text: string) => void;
  onLeave: () => void;
}) {
  const wing = wingOf(puzzle.category);
  const last = session.index + 1 >= session.ids.length;
  const [draft, setDraft] = useState("");
  const [shaking, setShaking] = useState(false);

  useEffect(() => {
    setDraft("");
  }, [puzzle.id]);

  useEffect(() => {
    if (!session.shake) return;
    setShaking(true);
    inputRef.current?.focus();
    const t = window.setTimeout(() => setShaking(false), 450);
    return () => window.clearTimeout(t);
  }, [session.shake, inputRef]);

  return (
    <main className="mx-auto max-w-3xl px-4 pb-16 pt-4">
      <div className="mb-4 flex items-center justify-between gap-3 text-sm">
        <button onClick={onLeave} className="text-muted hover:text-ink">
          ← Cabinet
        </button>
        <p className="text-center">
          <span className="tracking-[0.16em] text-[11px]" style={{ color: wing.pigment }}>
            {session.title.toUpperCase()}
          </span>
          <span className="mx-2 text-ink/30">·</span>
          {session.index + 1} / {session.ids.length}
        </p>
        <p className="tabular-nums text-olive">{session.score}</p>
      </div>

      <div className="mb-4 flex justify-center gap-1.5" aria-hidden>
        {session.ids.map((id, i) => {
          const item = session.log.find((l) => l.id === id);
          return (
            <span
              key={id}
              className={cn(
                "h-1.5 rounded-full",
                i === session.index ? "w-6 bg-olive" : "w-3",
                item?.ok ? "bg-olive" : item ? "bg-oxblood/70" : "bg-ink/15",
              )}
            />
          );
        })}
      </div>

      <Gilt label={wing.label.toUpperCase()} pigment={wing.pigment}>
        <div className="relative aspect-[8/5]">
          <SceneView id={puzzle.id} />
          {session.revealed && (
            <div
              className={cn(
                "stamp absolute right-4 top-4 rounded-sm border-2 px-3 py-1 font-serif text-xl tracking-widest",
                session.lastOk
                  ? "border-olive text-olive"
                  : "border-oxblood text-oxblood",
              )}
            >
              {session.lastOk ? "NAMED" : "NOTED"}
            </div>
          )}
        </div>
      </Gilt>

      <div className="relative z-10 mx-auto -mt-4 w-fit rounded-sm bg-cream px-5 py-2 shadow-sm ring-1 ring-ink/10">
        <p className="text-[10px] tracking-[0.22em] text-gold">SPECIMEN</p>
        <p className="font-serif text-xl">{puzzle.prompt}</p>
        <p className="text-center text-xs text-muted">Say the costume as one name.</p>
      </div>

      {!session.revealed ? (
        <form
          className={cn("mt-6", shaking && "shake")}
          onSubmit={(e) => {
            e.preventDefault();
            onSubmit(draft);
          }}
        >
          <label className="text-[11px] tracking-[0.18em] text-muted" htmlFor="naming">
            YOUR NAMING
          </label>
          <div className="mt-1 flex items-end gap-3">
            <input
              id="naming"
              ref={inputRef}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder={puzzle.placeholder ?? "Type the name…"}
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
              className="name-line"
            />
            <button
              type="submit"
              className="mb-1 shrink-0 rounded-full bg-olive px-4 py-2 text-sm text-cream"
            >
              Name it
            </button>
          </div>
          <div aria-live="polite" className="mt-3 min-h-6 text-sm text-oxblood">
            {session.feedback}
          </div>
          {session.hints > 0 && (
            <div className="mt-2 space-y-1 rounded-xl bg-cream/70 px-4 py-3 text-sm">
              {session.hints >= 1 && <p>{puzzle.hints[0]}</p>}
              {session.hints >= 2 && (
                <p className="font-serif text-lg tracking-[0.14em] text-olive">{puzzle.hints[1]}</p>
              )}
              {session.hints >= 3 && (
                <p>
                  First letter <span className="font-serif text-2xl text-olive">{puzzle.hints[2]}</span>
                </p>
              )}
            </div>
          )}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            {(
              [
                ["A nudge", 0],
                ["The break", 1],
                ["First letter", 2],
              ] as const
            ).map(([label, need]) => (
              <button
                key={label}
                type="button"
                disabled={session.hints !== need}
                onClick={onHint}
                className="rounded-full border border-ink/15 px-3 py-1.5 text-sm disabled:cursor-not-allowed disabled:opacity-40"
              >
                {label}
              </button>
            ))}
            <button type="button" onClick={onGiveup} className="ml-auto text-sm text-muted underline underline-offset-4">
              Hang it unsolved
            </button>
          </div>
        </form>
      ) : (
        <div ref={revealRef} className="rise mt-6 rounded-2xl border border-ink/10 bg-cream/80 p-5">
          <p className="text-[11px] tracking-[0.2em] text-gold">{session.lastOk ? "THE LABEL" : "THE LABEL, UNHUNG"}</p>
          <h2 className="mt-1 font-serif text-4xl text-olive">{puzzle.answer}</h2>
          <p className="mt-1 font-serif italic text-muted">{puzzle.say}</p>
          <p className="mt-4 leading-relaxed">{puzzle.explanation}</p>
          <p className="mt-3 border-t border-ink/10 pt-3 text-sm leading-relaxed text-muted">{puzzle.fact}</p>
          {session.mode !== "review" && (
            <p className="mt-3 text-sm text-olive">
              {session.lastOk ? `+${session.lastPoints}` : "No points — the frame stays in the foyer."}
              {session.streak > 1 && session.lastOk ? ` · a run of ${session.streak}` : ""}
            </p>
          )}
          <button
            onClick={onNext}
            className="mt-5 rounded-full bg-olive px-5 py-2.5 text-sm text-cream"
          >
            {session.mode === "review" ? "Back to the cabinet" : last ? "See the hanging" : "Next frame"}
          </button>
        </div>
      )}
    </main>
  );
}

function Results({
  session,
  openId,
  onOpen,
  copied,
  onCopy,
  onAgain,
  onHome,
  perfect,
}: {
  session: Session;
  openId: string | null;
  onOpen: (id: string | null) => void;
  copied: boolean;
  onCopy: () => void;
  onAgain: () => void;
  onHome: () => void;
  perfect: boolean;
}) {
  const rank = rankFor(session.named, session.ids.length);
  return (
    <main className="relative mx-auto max-w-5xl px-4 py-10">
      {perfect && <Confetti />}
      <p className="text-[11px] tracking-[0.22em] text-gold">{session.title.toUpperCase()}</p>
      <h1 className="mt-2 max-w-3xl font-serif text-5xl leading-[0.95] text-olive md:text-6xl">{rank.title}</h1>
      <p className="mt-4 max-w-xl text-lg leading-relaxed">{rank.line}</p>
      <div className="mt-6 flex flex-wrap gap-6 text-sm">
        <p>
          <span className="block text-[11px] tracking-[0.16em] text-muted">NAMED</span>
          <span className="font-serif text-3xl">
            {session.named}
            <span className="text-lg text-muted"> / {session.ids.length}</span>
          </span>
        </p>
        <p>
          <span className="block text-[11px] tracking-[0.16em] text-muted">SCORE</span>
          <span className="font-serif text-3xl">{session.score}</span>
        </p>
      </div>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {session.log.map((item) => {
          const puzzle = puzzleById(item.id);
          if (!puzzle) return null;
          const open = openId === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onOpen(open ? null : item.id)}
              className="text-left"
            >
              <Gilt>
                <div className="relative aspect-[8/5]">
                  <SceneView id={item.id} />
                  <span
                    className={cn(
                      "absolute right-2 top-2 rounded-full px-2 py-0.5 text-[10px] tracking-widest text-cream",
                      item.ok ? "bg-olive" : "bg-oxblood",
                    )}
                  >
                    {item.ok ? "NAMED" : "NOTED"}
                  </span>
                </div>
              </Gilt>
              <p className="mt-2 font-serif text-xl">{puzzle.answer}</p>
              <p className="text-sm text-muted">{puzzle.say}</p>
              {open && <p className="mt-2 text-sm leading-relaxed">{puzzle.explanation}</p>}
            </button>
          );
        })}
      </div>
      <div className="mt-8 flex flex-wrap gap-3">
        <button onClick={onAgain} className="rounded-full bg-olive px-5 py-3 text-sm text-cream">
          Walk it again
        </button>
        <button onClick={onHome} className="rounded-full border border-ink/15 px-5 py-3 text-sm">
          Back to the cabinet
        </button>
        <button onClick={onCopy} className="rounded-full px-4 py-3 text-sm text-muted underline underline-offset-4">
          {copied ? "Copied" : "Copy the line"}
        </button>
      </div>
    </main>
  );
}

function Almanac({
  solved,
  filter,
  confirmReset,
  onFilter,
  onPlay,
  onResetAsk,
  onReset,
}: {
  solved: string[];
  filter: Filter;
  confirmReset: boolean;
  onFilter: (f: Filter) => void;
  onPlay: (id: string) => void;
  onResetAsk: (on: boolean) => void;
  onReset: () => void;
}) {
  const list = puzzles.filter((p) => {
    if (filter === "all") return true;
    if (filter === "open") return !solved.includes(p.id);
    return p.category === filter;
  });
  const chips: { id: Filter; label: string }[] = [
    { id: "all", label: "All" },
    { id: "open", label: "Unhung" },
    ...wings.map((w) => ({ id: w.id as Filter, label: w.label })),
  ];
  return (
    <main className="mx-auto max-w-6xl px-4 py-8 md:px-8">
      <p className="text-[11px] tracking-[0.22em] text-gold">THE ALMANAC</p>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-serif text-4xl text-olive md:text-5xl">Every frame, labeled or not.</h1>
        <p className="text-sm text-muted">
          {solved.length} of {puzzles.length} hung
        </p>
      </div>
      <div className="mt-5 flex flex-wrap gap-2">
        {chips.map((chip) => (
          <button
            key={chip.id}
            onClick={() => onFilter(chip.id)}
            className={cn(
              "rounded-full px-3 py-1.5 text-sm",
              filter === chip.id ? "bg-olive text-cream" : "border border-ink/10 hover:border-ink/30",
            )}
          >
            {chip.label}
          </button>
        ))}
      </div>
      <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((puzzle) => {
          const hung = solved.includes(puzzle.id);
          const wing = wingOf(puzzle.category);
          return (
            <article key={puzzle.id} className="flex flex-col">
              <button onClick={() => onPlay(puzzle.id)} className="text-left">
                <Gilt label={wing.kicker.toUpperCase()} pigment={wing.pigment}>
                  <div className="aspect-[8/5]">
                    <SceneView id={puzzle.id} />
                  </div>
                </Gilt>
              </button>
              <div className="mt-2 flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm text-muted">{puzzle.prompt}</p>
                  {hung ? (
                    <>
                      <p className="font-serif text-2xl">{puzzle.answer}</p>
                      <p className="text-sm italic text-muted">{puzzle.say}</p>
                    </>
                  ) : (
                    <p className="font-serif text-xl text-ink/40">Unhung</p>
                  )}
                </div>
                <button
                  onClick={() => onPlay(puzzle.id)}
                  className="shrink-0 rounded-full border border-ink/15 px-3 py-1.5 text-xs"
                >
                  {hung ? "Replay" : "Try"}
                </button>
              </div>
            </article>
          );
        })}
      </div>
      {list.length === 0 && (
        <p className="mt-10 font-serif text-2xl text-olive">Nothing in this drawer. The cabinet is either full or empty of excuses.</p>
      )}
      <div className="mt-12 border-t border-ink/10 pt-6 text-sm text-muted">
        {!confirmReset ? (
          <button onClick={() => onResetAsk(true)} className="underline underline-offset-4">
            Clear the cabinet
          </button>
        ) : (
          <p>
            Take every frame down? This forgets scores and the daily streak.
            <button onClick={onReset} className="ml-3 text-oxblood underline">
              Yes, clear it
            </button>
            <button onClick={() => onResetAsk(false)} className="ml-3 underline">
              Keep them
            </button>
          </p>
        )}
      </div>
    </main>
  );
}
