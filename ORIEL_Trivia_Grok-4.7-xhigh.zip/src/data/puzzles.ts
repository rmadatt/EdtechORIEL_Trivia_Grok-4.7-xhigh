export type Category = "geography" | "math" | "physics" | "chemistry" | "biology";

export type Nudge = { words: string[]; nudge: string };

export type Puzzle = {
  id: string;
  category: Category;
  answer: string;
  aliases: string[];
  prompt: string;
  say: string;
  hints: [string, string, string];
  literal: Nudge[];
  near?: Nudge[];
  explanation: string;
  fact: string;
  difficulty: 1 | 2 | 3;
  placeholder?: string;
};

export const wings: {
  id: Category;
  label: string;
  kicker: string;
  blurb: string;
  pigment: string;
}[] = [
  {
    id: "geography",
    label: "Geography",
    kicker: "Cities",
    blurb: "Capitals hiding in ordinary objects, said as one breath.",
    pigment: "#1e4f4a",
  },
  {
    id: "math",
    label: "Mathematics",
    kicker: "Numbers",
    blurb: "Constants, angles, and sequences that arrived in costume.",
    pigment: "#243056",
  },
  {
    id: "physics",
    label: "Physics",
    kicker: "Laws",
    blurb: "Units and forces that sound like something else entirely.",
    pigment: "#8c3d22",
  },
  {
    id: "chemistry",
    label: "Chemistry",
    kicker: "Elements",
    blurb: "The table, the ions, and the families, drawn as still lifes.",
    pigment: "#5c3048",
  },
  {
    id: "biology",
    label: "Biology",
    kicker: "Life",
    blurb: "Organs, tissues, and kingdoms misheard on purpose.",
    pigment: "#2f4a2c",
  },
];

export const puzzles: Puzzle[] = [
  {
    id: "moscow",
    category: "geography",
    answer: "Moscow",
    aliases: ["moskva"],
    prompt: "Guess the city",
    say: "mosque + cow",
    hints: [
      "Two things, said as one word. One is a place of worship.",
      "MOS · COW",
      "M",
    ],
    literal: [
      {
        words: ["mosque", "cow", "cows", "cattle", "islam", "mecca", "medina"],
        nudge: "You have named a piece of the costume. Say both things as one city.",
      },
    ],
    near: [
      {
        words: ["istanbul", "cairo", "baghdad", "russia", "kremlin"],
        nudge: "The neighborhood is right. Listen to the building and the animal together.",
      },
    ],
    explanation:
      "A mosque beside a cow. Say them in one breath and you are standing in Russia’s capital.",
    fact: "Moscow grew up on the Moskva River. It has been Russia’s capital, with one long interruption, since the late Middle Ages.",
    difficulty: 1,
  },
  {
    id: "athens",
    category: "geography",
    answer: "Athens",
    aliases: ["athina", "athenai"],
    prompt: "Guess the city",
    say: "eight hens",
    hints: [
      "Count the birds. The border is a Greek key, and the hilltop is an old temple.",
      "EIGHT · HENS",
      "A",
    ],
    literal: [
      {
        words: ["hens", "hen", "eight", "8", "chickens", "chicken", "birds"],
        nudge: "That’s the count, or the birds. Which city sounds like eight hens?",
      },
    ],
    near: [
      {
        words: ["greece", "sparta", "corinth", "thebes", "parthenon", "acropolis"],
        nudge: "Greece, yes. The city is the number of hens said quickly.",
      },
    ],
    explanation: "Eight hens, inside a Greek key. Eight hens — Athens.",
    fact: "Athens is one of the oldest continuously lived-in cities, named in myth for the goddess Athena.",
    difficulty: 2,
  },
  {
    id: "helsinki",
    category: "geography",
    answer: "Helsinki",
    aliases: ["helsingfors"],
    prompt: "Guess the city",
    say: "hen + sink + ski",
    hints: [
      "Three objects, left to right. The last one is very much at home in Finland.",
      "HEN · SINK · SKI",
      "H",
    ],
    literal: [
      {
        words: ["hen", "sink", "ski", "skis", "faucet", "chicken"],
        nudge: "Each object is a syllable. Say all three as a single capital.",
      },
    ],
    near: [
      {
        words: ["finland", "oslo", "stockholm", "tampere", "nordic"],
        nudge: "The pines are a clue to the country. The three objects spell the capital.",
      },
    ],
    explanation:
      "A hen, a sink, and a ski. Hen-sink-ski lands you in Finland’s capital, close enough to hear the harbor.",
    fact: "Helsinki sits on the Gulf of Finland. Its Swedish name is Helsingfors — also accepted, if you arrived by the other door.",
    difficulty: 3,
  },
  {
    id: "taipei",
    category: "geography",
    answer: "Taipei",
    aliases: ["taipeh"],
    prompt: "Guess the city",
    say: "tie + pie",
    hints: [
      "A piece of clothing and a dessert. A lantern is only the weather.",
      "TIE · PIE",
      "T",
    ],
    literal: [
      {
        words: ["tie", "necktie", "pie", "dessert", "lantern"],
        nudge: "You named the costume. Say the necktie and the pie as one city.",
      },
    ],
    near: [
      {
        words: ["taiwan", "taichung", "tokyo", "china"],
        nudge: "The lantern nods toward the island. The pun is tie-pie.",
      },
    ],
    explanation: "A necktie and a pie. Tie-pie — Taipei.",
    fact: "Taipei lies in a basin at the northern end of Taiwan, with mountains close enough to change the evening light.",
    difficulty: 1,
  },
  {
    id: "vancouver",
    category: "geography",
    answer: "Vancouver",
    aliases: [],
    prompt: "Guess the city",
    say: "van + cooler",
    hints: [
      "A vehicle and an ice chest, with mountains enough to keep the ice honest.",
      "VAN · COOLER",
      "V",
    ],
    literal: [
      {
        words: ["van", "cooler", "ice chest", "icebox", "camper", "truck"],
        nudge: "Those are the two halves. Say them as one Pacific city.",
      },
    ],
    near: [
      {
        words: ["seattle", "canada", "british columbia", "victoria"],
        nudge: "The rain and the peaks are shared with the neighbors. Van plus cooler is more specific.",
      },
    ],
    explanation: "A van beside a cooler. Van-cooler — Vancouver.",
    fact: "Vancouver stands between the Pacific and the Coast Mountains in British Columbia, which is why the cooler never quite goes empty.",
    difficulty: 2,
  },
  {
    id: "cairo",
    category: "geography",
    answer: "Cairo",
    aliases: ["al qahira", "alqahira", "el qahira"],
    prompt: "Guess the city",
    say: "car + row",
    hints: [
      "A vehicle and a boat with oars. The triangles in the back are only a confirmation.",
      "CAR · ROW",
      "C",
    ],
    literal: [
      {
        words: ["car", "row", "rowboat", "boat", "oar", "oars", "pyramid", "pyramids"],
        nudge: "You have a piece, or the skyline. Say the car and the row together.",
      },
    ],
    near: [
      {
        words: ["egypt", "giza", "alexandria", "nile"],
        nudge: "Egypt, yes. The capital is the car and the rowboat said as one word.",
      },
    ],
    explanation: "A car and a rowboat. Car-row — Cairo, with the pyramids agreeing from the desert.",
    fact: "Cairo spreads along the Nile just south of the delta, and has been Egypt’s capital for a thousand years.",
    difficulty: 2,
  },
  {
    id: "london",
    category: "geography",
    answer: "London",
    aliases: ["londinium"],
    prompt: "Guess the city",
    say: "lawn + don",
    hints: [
      "Striped grass, and a university teacher in a gown. In Britain that teacher is called a don.",
      "LAWN · DON",
      "L",
    ],
    literal: [
      {
        words: ["lawn", "grass", "don", "gown", "mortarboard", "professor", "teacher", "bus"],
        nudge: "The figure is a don — a tutor in a gown. Put the don on the lawn and say the city.",
      },
    ],
    near: [
      {
        words: ["oxford", "cambridge", "england", "britain", "thames"],
        nudge: "The gown could belong to either university town. Lawn plus don is the larger city on the river.",
      },
    ],
    explanation: "A lawn and a don. Lawn-don — London. The little red bus was only being helpful.",
    fact: "London began as a Roman crossing of the Thames. A don, in British usage, is a university tutor.",
    difficulty: 2,
  },
  {
    id: "tehran",
    category: "geography",
    answer: "Tehran",
    aliases: ["teheran"],
    prompt: "Guess the city",
    say: "tea + ran",
    hints: [
      "A glass of tea, then someone in a hurry. The arch is Persian on purpose.",
      "TEA · RAN",
      "T",
    ],
    literal: [
      {
        words: ["tea", "runner", "running", "ran", "glass", "chai"],
        nudge: "Tea, then the act of running. Say them as one capital.",
      },
    ],
    near: [
      {
        words: ["iran", "persia", "isfahan", "shiraz"],
        nudge: "The country is right. Tea plus ran names the capital.",
      },
    ],
    explanation: "Tea, then a person who ran. Tea-ran — Tehran.",
    fact: "Tehran sits at the foot of the Alborz mountains. Tea, served in a small glass, is the city’s everyday ceremony.",
    difficulty: 2,
  },
  {
    id: "seoul",
    category: "geography",
    answer: "Seoul",
    aliases: [],
    prompt: "Guess the city",
    say: "sole",
    hints: [
      "Turn the shoe over. The roof in the distance is only a nod.",
      "It sounds exactly like the bottom of the shoe.",
      "S",
    ],
    literal: [
      {
        words: ["sole", "shoe", "boot", "foot", "tread"],
        nudge: "That’s what you see. Which city is pronounced like the sole?",
      },
    ],
    near: [
      {
        words: ["soul", "korea", "busan", "pyongyang"],
        nudge: "Listen one consonant more carefully. The shoe sole is the whole pun.",
      },
    ],
    explanation: "The sole of a shoe. Sole — Seoul.",
    fact: "Seoul has been a capital on the Han River for six centuries, and it is pronounced like the bottom of a shoe.",
    difficulty: 1,
  },
  {
    id: "delhi",
    category: "geography",
    answer: "Delhi",
    aliases: ["dilli", "new delhi", "newdelhi"],
    prompt: "Guess the city",
    say: "deli",
    hints: [
      "The whole frame is a sandwich counter. Say it with an older passport.",
      "It sounds like the shop in front of you.",
      "D",
    ],
    literal: [
      {
        words: ["deli", "delicatessen", "sandwich", "sandwiches", "salami"],
        nudge: "That’s the shop. The city sounds the same and sits behind a sandstone arch.",
      },
    ],
    near: [
      {
        words: ["india", "mumbai", "agra", "jaipur"],
        nudge: "India, yes. The counter is a deli, and the capital sounds just like it.",
      },
    ],
    explanation: "A deli counter, marigolds and all. Deli — Delhi.",
    fact: "Delhi has been the seat of successive empires. New Delhi, its planned imperial core, is accepted here too.",
    difficulty: 1,
  },
  {
    id: "seven",
    category: "math",
    answer: "7",
    aliases: ["seven", "vii", "prime 7", "the prime 7"],
    prompt: "Guess the prime number",
    say: "seven stars",
    hints: [
      "Count the stars in the rosette. The prompt has already told you it is prime.",
      "A single digit. Only two factors: 1 and itself.",
      "7",
    ],
    literal: [
      {
        words: ["stars", "star", "seven stars", "constellation", "rosette"],
        nudge: "Those are the costume. The prime is the count.",
      },
    ],
    near: [
      {
        words: ["pleiades", "big dipper", "ursa major", "plough", "six", "6", "five", "5", "eleven", "11"],
        nudge: "Count again, slowly, including the one in the middle. It is a prime.",
      },
    ],
    explanation: "Seven stars. Seven is prime — divisible only by 1 and itself — and it arrived in evening dress.",
    fact: "Seven is the fourth prime, and the only one that is one less than a perfect cube (8).",
    difficulty: 1,
    placeholder: "A digit, or its name…",
  },
  {
    id: "pi",
    category: "math",
    answer: "pi",
    aliases: ["π", "3.14", "3.1416", "3.14159"],
    prompt: "Guess the constant",
    say: "pie",
    hints: [
      "It is round, and it is not the dessert. Think of circles.",
      "It sounds exactly like the dish in the frame.",
      "π",
    ],
    literal: [
      {
        words: ["pie", "dessert", "tart", "pastry", "cake", "pizza"],
        nudge: "That’s the costume. Name the constant it sounds like.",
      },
    ],
    near: [
      {
        words: ["circle", "circumference", "tau", "3", "three"],
        nudge: "Related, but the frame wants the constant itself — the one a pie is named beside.",
      },
    ],
    explanation: "A pie, round as a circle. The constant is pi: circumference divided by diameter.",
    fact: "Pi is irrational. Its decimal never settles into a repeating pattern, however many digits you bake.",
    difficulty: 1,
  },
  {
    id: "acute",
    category: "math",
    answer: "Acute angle",
    aliases: ["acute", "an acute angle"],
    prompt: "Guess the kind of angle",
    say: "a cute angel",
    hints: [
      "The corner on the floor is sharper than a square corner. The figure is a pun.",
      "A · CUTE  (and the figure is an angel)",
      "A",
    ],
    literal: [
      {
        words: ["angel", "cute", "cute angel", "halo", "wings"],
        nudge: "That’s who you see. What kind of angle sounds like a cute angel?",
      },
    ],
    near: [
      {
        words: ["right angle", "right", "obtuse", "reflex", "degree"],
        nudge: "Look at the chalk on the floor. This corner is smaller than 90 degrees.",
      },
    ],
    explanation: "A cute angel in a sharp corner. Cute angel — an acute angle, under 90 degrees.",
    fact: "Acute angles are sharper than a right angle. In a triangle, an acute angle leaves room for the other two to be acute as well.",
    difficulty: 2,
  },
  {
    id: "tangent",
    category: "math",
    answer: "Tangent",
    aliases: ["tan"],
    prompt: "Guess the trigonometry term",
    say: "tan gent",
    hints: [
      "A sun-tanned gentleman, and his cane touches the circle at exactly one point.",
      "TAN · GENT",
      "T",
    ],
    literal: [
      {
        words: ["man", "gentleman", "gent", "cane", "circle", "sunglasses", "tanned", "sunburn"],
        nudge: "Describe him in two short words — tan, then gent — and you have the term.",
      },
    ],
    near: [
      {
        words: ["sine", "cosine", "secant", "chord", "radius"],
        nudge: "Neighboring words. This one is the line that kisses the circle once, and the man who is tanned.",
      },
    ],
    explanation:
      "A tanned gent whose cane just kisses a circle. Tan gent — tangent: a line that touches a curve at exactly one point.",
    fact: "In a right triangle, the tangent of an angle is the opposite side divided by the adjacent side.",
    difficulty: 2,
  },
  {
    id: "logarithm",
    category: "math",
    answer: "Logarithm",
    aliases: ["log", "logs"],
    prompt: "Guess the function",
    say: "log + rhythm",
    hints: [
      "A piece of timber, keeping time. It undoes an exponential.",
      "LOG · RHYTHM",
      "L",
    ],
    literal: [
      {
        words: ["log", "wood", "drum", "drums", "rhythm", "music", "timber"],
        nudge: "Log plus rhythm. Say them as the function that asks “to what power?”",
      },
    ],
    near: [
      {
        words: ["exponential", "exponent", "algorithm", "ln"],
        nudge: "Related machinery. The frame is log-rhythm — the inverse of an exponential.",
      },
    ],
    explanation: "A log keeping rhythm. Log-rhythm — a logarithm, the inverse of an exponential.",
    fact: "If 10³ = 1000, the base-10 logarithm of 1000 is 3. The drum was only there so you would say it aloud.",
    difficulty: 3,
  },
  {
    id: "integer",
    category: "math",
    answer: "Integer",
    aliases: ["integers"],
    prompt: "Guess the kind of number",
    say: "in-tea-jar",
    hints: [
      "Read the tag on the jar, then the drink, then the container.",
      "IN · TEA · JAR",
      "I",
    ],
    literal: [
      {
        words: ["tea", "jar", "in", "drink", "mason jar"],
        nudge: "Read the tag, the drink, and the jar as one mathematical word.",
      },
    ],
    near: [
      {
        words: ["whole number", "whole numbers", "natural number", "natural numbers", "fraction", "decimal"],
        nudge: "Close. This set includes the negatives and zero — in a tea jar.",
      },
    ],
    explanation: "In a tea jar. In-tea-jar — an integer: …−2, −1, 0, 1, 2…",
    fact: "Integers have no fractional part. Whether zero is a “whole number” depends on the textbook; it is certainly an integer.",
    difficulty: 2,
  },
  {
    id: "radius",
    category: "math",
    answer: "Radius",
    aliases: ["radii"],
    prompt: "Guess the length",
    say: "radio",
    hints: [
      "The gold line runs from the center of the circle to the edge. The set it sits in is a pun.",
      "It sounds like the radio.",
      "R",
    ],
    literal: [
      {
        words: ["radio", "speaker", "wireless", "antenna", "dial"],
        nudge: "That’s the costume. The length from center to edge sounds almost like it.",
      },
    ],
    near: [
      {
        words: ["diameter", "circumference", "chord", "arc", "pi"],
        nudge: "A cousin of the circle. This one is half the diameter — and it sounds like the radio.",
      },
    ],
    explanation: "A radio, and a line from center to rim. Radio — radius.",
    fact: "The radius is half the diameter. Twice pi times the radius is the long way around.",
    difficulty: 2,
  },
  {
    id: "squareroot",
    category: "math",
    answer: "Square root",
    aliases: ["squareroot", "sqrt", "radical"],
    prompt: "Guess the operation",
    say: "a square root vegetable",
    hints: [
      "The vegetable has been squared, and it still has a root. What operation is that?",
      "Two words. The shape, then what all roots are.",
      "S",
    ],
    literal: [
      {
        words: ["carrot", "vegetable", "beet", "root", "square", "turnip"],
        nudge: "You are describing the picture. The operation is both words together.",
      },
    ],
    near: [
      {
        words: ["cube root", "square", "squared", "power", "radical sign"],
        nudge: "Nearly. It undoes squaring — say both words the picture is spelling.",
      },
    ],
    explanation: "A square root vegetable. The operation that undoes squaring: the square root.",
    fact: "The square root of 49 is 7 — which is why the seven stars feel at home in this wing.",
    difficulty: 2,
  },
  {
    id: "sine",
    category: "math",
    answer: "Sine",
    aliases: ["sin"],
    prompt: "Guess the trigonometry term",
    say: "sign",
    hints: [
      "The board is a sign, and the curve drawn on it is a hint from the other door.",
      "It sounds exactly like the object.",
      "S",
    ],
    literal: [
      {
        words: ["sign", "signpost", "board", "wave", "road sign"],
        nudge: "That’s what it is. In trigonometry, the homophone is a ratio.",
      },
    ],
    near: [
      {
        words: ["cosine", "tangent", "wave", "signal"],
        nudge: "The curve is a clue, but the pun is the sign itself.",
      },
    ],
    explanation: "A sign. Say it and you have sine — opposite over hypotenuse.",
    fact: "Sine starts at 0, rises to 1 at a quarter turn, and repeats. The wave on the board is that habit, drawn.",
    difficulty: 1,
  },
  {
    id: "fibonacci",
    category: "math",
    answer: "Fibonacci",
    aliases: ["fibonacci sequence", "fibonaccis sequence"],
    prompt: "Guess the sequence",
    say: "rabbits, 1 · 1 · 2 · 3 · 5",
    hints: [
      "Count each group. Every pile is the sum of the two before it. An Italian mathematician owned the rabbits.",
      "A surname. The groups are 1, 1, 2, 3, 5.",
      "F",
    ],
    literal: [
      {
        words: ["rabbits", "rabbit", "bunnies", "bunny", "1 1 2 3 5", "11235"],
        nudge: "That’s the start of it. Whose sequence sends rabbits multiplying like that?",
      },
    ],
    near: [
      {
        words: ["pascal", "prime", "primes", "geometric", "arithmetic"],
        nudge: "Another famous list. This one begins 1, 1, 2, 3, 5, and was posed with rabbits.",
      },
    ],
    explanation:
      "Rabbits grouped 1, 1, 2, 3, 5 — each count the sum of the two before it. Fibonacci’s sequence, born as a puzzle about multiplying rabbits.",
    fact: "Leonardo of Pisa, called Fibonacci, wrote the sequence into European mathematics in 1202, in a problem about rabbits.",
    difficulty: 2,
  },
  {
    id: "newton",
    category: "physics",
    answer: "Newton",
    aliases: ["isaac newton", "sir isaac newton"],
    prompt: "Guess the scientist",
    say: "newt + on",
    hints: [
      "A small amphibian, sitting on the famous fruit.",
      "NEWT · ON",
      "N",
    ],
    literal: [
      {
        words: ["newt", "salamander", "apple", "fruit"],
        nudge: "Newt, on the apple. Say it as a surname.",
      },
    ],
    near: [
      {
        words: ["gravity", "einstein", "galileo", "force", "hooke"],
        nudge: "The apple is his legend. The frame wants the person: newt-on.",
      },
    ],
    explanation: "A newt on an apple. Newt-on — Newton, who tied a falling apple to the force that holds the Moon.",
    fact: "The newton, named for him, is the force that accelerates one kilogram by one meter per second squared.",
    difficulty: 2,
  },
  {
    id: "joule",
    category: "physics",
    answer: "Joule",
    aliases: ["joules", "j"],
    prompt: "Guess the unit of energy",
    say: "jewel",
    hints: [
      "It is pronounced like the gem on the cushion.",
      "One syllable. It sounds like the stone.",
      "J",
    ],
    literal: [
      {
        words: ["jewel", "jewels", "gem", "ruby", "diamond", "sapphire", "stone"],
        nudge: "That’s the costume. The unit of energy is the homophone.",
      },
    ],
    near: [
      {
        words: ["watt", "newton", "calorie", "energy", "work"],
        nudge: "Energy is the right shelf. The unit that sounds like the gem is more specific.",
      },
    ],
    explanation: "A jewel. In physics that pronunciation is a joule, the unit of energy and of work.",
    fact: "One joule is a force of one newton acting through one meter — about the lift of a small apple through a short height.",
    difficulty: 1,
  },
  {
    id: "watt",
    category: "physics",
    answer: "Watt",
    aliases: ["watts", "w"],
    prompt: "Guess the unit of power",
    say: "what?",
    hints: [
      "The bulb is asking a question. Say that question as a unit.",
      "It sounds like the glowing question mark.",
      "W",
    ],
    literal: [
      {
        words: ["what", "question", "question mark", "bulb", "light", "lamp"],
        nudge: "Say the question mark as a unit of power.",
      },
    ],
    near: [
      {
        words: ["joule", "volt", "amp", "ampere", "power", "energy"],
        nudge: "Power is the right idea. The unit sounds exactly like “what?”",
      },
    ],
    explanation: "A glowing what? Watt — the unit of power, one joule of energy each second.",
    fact: "Named for James Watt, who greatly improved the steam engine. He did not invent the idea of steam from nothing.",
    difficulty: 1,
  },
  {
    id: "current",
    category: "physics",
    answer: "Current",
    aliases: ["electric current", "electrical current"],
    prompt: "Guess the electrical quantity",
    say: "currant",
    hints: [
      "The berries on the wire are a fruit pun. Charge is flowing.",
      "It sounds like the dark berries.",
      "C",
    ],
    literal: [
      {
        words: ["currant", "currants", "berry", "berries", "wire", "fruit"],
        nudge: "Those are currants. The quantity on the wire sounds the same.",
      },
    ],
    near: [
      {
        words: ["voltage", "volt", "ampere", "amp", "resistance", "power"],
        nudge: "A neighbor in the circuit. This one is the flow, and it sounds like the fruit.",
      },
    ],
    explanation: "Currants threaded on a wire. Currant — current, the flow of electric charge.",
    fact: "Current is measured in amperes. One ampere is one coulomb of charge passing a point each second.",
    difficulty: 2,
  },
  {
    id: "ampere",
    category: "physics",
    answer: "Ampere",
    aliases: ["amp", "amps", "amperes", "a"],
    prompt: "Guess the unit",
    say: "ant + pear",
    hints: [
      "An insect and a fruit, standing on the wire from the neighboring frame.",
      "ANT · PEAR",
      "A",
    ],
    literal: [
      {
        words: ["ant", "pear", "insect", "fruit"],
        nudge: "Say the ant and the pear as one unit of current.",
      },
    ],
    near: [
      {
        words: ["volt", "ohm", "watt", "current", "coulomb"],
        nudge: "Current is what it measures. The unit is ant-pear.",
      },
    ],
    explanation: "An ant with a pear. Ant-pear — the ampere, unit of electric current.",
    fact: "The ampere is a base unit of the SI, named for André-Marie Ampère, who mapped how currents push and pull.",
    difficulty: 2,
  },
  {
    id: "relativity",
    category: "physics",
    answer: "Relativity",
    aliases: ["theory of relativity", "special relativity", "general relativity"],
    prompt: "Guess the theory",
    say: "relatives at tea",
    hints: [
      "A family, a pot of tea, and clocks that do not agree. Say the gathering as a theory.",
      "RELATIVES · TEA",
      "R",
    ],
    literal: [
      {
        words: ["tea", "relatives", "family", "uncle", "aunt", "teapot", "party"],
        nudge: "Relatives, at tea. That gathering is the name of the theory.",
      },
    ],
    near: [
      {
        words: ["einstein", "gravity", "newton", "quantum", "time"],
        nudge: "He wrote it. The frame wants the theory: relatives at tea.",
      },
    ],
    explanation:
      "Relatives at tea. Relativity — how time, space, and gravity depend on who is watching, and how they move.",
    fact: "In special relativity the speed of light is the same for every observer, and a moving clock ticks slow relative to a resting one.",
    difficulty: 3,
  },
  {
    id: "density",
    category: "physics",
    answer: "Density",
    aliases: [],
    prompt: "Guess the quantity",
    say: "den + city",
    hints: [
      "A fox’s home built into a crowded block of buildings.",
      "DEN · CITY",
      "D",
    ],
    literal: [
      {
        words: ["den", "city", "fox", "apartment", "buildings", "crowd"],
        nudge: "Den, city. Say them as the quantity that packs mass into volume.",
      },
    ],
    near: [
      {
        words: ["mass", "weight", "volume", "pressure", "gravity"],
        nudge: "Mass is half the story. This frame is how much mass sits in how much space: den-city.",
      },
    ],
    explanation: "A den in the city. Den-city — density, mass divided by volume.",
    fact: "Water sits near 1 gram per cubic centimeter. The fox would rather you didn’t compare it with lead, which is about eleven times that.",
    difficulty: 2,
  },
  {
    id: "vacuum",
    category: "physics",
    answer: "Vacuum",
    aliases: ["a vacuum"],
    prompt: "Guess the condition of this place",
    say: "a vacuum, where there is nothing to clean",
    hints: [
      "The appliance is a pun for the emptiness around it.",
      "The machine and the condition share a name.",
      "V",
    ],
    literal: [
      {
        words: ["vacuum cleaner", "hoover", "cleaner", "appliance", "space"],
        nudge: "That’s the costume, or the setting. What is true of a place with essentially no matter?",
      },
    ],
    near: [
      {
        words: ["zero", "nothing", "void", "pressure", "orbit"],
        nudge: "Emptiness, yes. The physics word is the same as the machine.",
      },
    ],
    explanation: "A vacuum cleaner, adrift where there is nothing to clean. A vacuum — space with essentially no matter.",
    fact: "Outer space is an excellent vacuum, though not a perfect one. A few particles still wander through.",
    difficulty: 1,
  },
  {
    id: "conduction",
    category: "physics",
    answer: "Conduction",
    aliases: ["thermal conduction"],
    prompt: "Guess how the heat is moving",
    say: "conductor",
    hints: [
      "One figure leads an orchestra. The other clue is heat traveling up a metal spoon.",
      "It sounds like the person with the baton.",
      "C",
    ],
    literal: [
      {
        words: ["conductor", "music", "orchestra", "baton", "pan", "spoon", "heat"],
        nudge: "The person is a conductor. The heat moving through metal has the matching name.",
      },
    ],
    near: [
      {
        words: ["convection", "radiation", "insulation", "current"],
        nudge: "The other ways heat travels are convection and radiation. This one goes through the material itself.",
      },
    ],
    explanation:
      "A conductor, and heat walking up a spoon. Conduction — energy moving through a material, neighbor to neighbor.",
    fact: "Metals conduct heat well because their loose electrons carry energy along, which is why the spoon handle betrays the soup.",
    difficulty: 3,
  },
  {
    id: "mass",
    category: "physics",
    answer: "Mass",
    aliases: [],
    prompt: "Guess the physics quantity",
    say: "a church mass, weighed",
    hints: [
      "The building is having a service, and the whole thing sits on a scale.",
      "The service and the quantity are the same word.",
      "M",
    ],
    literal: [
      {
        words: ["church", "service", "chapel", "scale", "worship", "pews"],
        nudge: "The service is called a mass. On a scale, that word is also a physics quantity.",
      },
    ],
    near: [
      {
        words: ["weight", "gravity", "density", "force", "newton"],
        nudge: "Weight is what a scale shows on Earth. The church service is naming the amount of matter, which does not change on the Moon.",
      },
    ],
    explanation: "A church mass, weighed. Mass — the amount of matter. A scale on Earth reports it as weight.",
    fact: "Mass stays the same on the Moon. Weight does not, because weight is mass times the local pull of gravity.",
    difficulty: 2,
  },
  {
    id: "gold",
    category: "chemistry",
    answer: "Gold",
    aliases: ["au"],
    prompt: "Guess the element",
    say: "atomic number 79, in gold",
    hints: [
      "The tile is painted the color of the answer. The number is its address on the table.",
      "Atomic number 79.",
      "G",
    ],
    literal: [
      {
        words: ["79", "seventy nine", "seventy-nine", "tile", "table", "periodic table"],
        nudge: "79 is its address. Name the element that lives there — the tile is already wearing the color.",
      },
    ],
    near: [
      {
        words: ["silver", "copper", "bronze", "brass", "metal", "aurum"],
        nudge: "A metal, yes, and aurum is the Latin door. The English name is the color of the tile.",
      },
    ],
    explanation: "A periodic-table tile numbered 79, bathed in gilt. 79 is gold. The symbol stayed offstage on purpose.",
    fact: "Gold is soft and deeply unreactive. A single gram can be beaten into a sheet about a square meter wide.",
    difficulty: 1,
  },
  {
    id: "carbon",
    category: "chemistry",
    answer: "Carbon",
    aliases: ["c"],
    prompt: "Guess the element",
    say: "car + bun",
    hints: [
      "A vehicle and a bread roll. The little lump of coal agrees.",
      "CAR · BUN",
      "C",
    ],
    literal: [
      {
        words: ["car", "bun", "bread", "coal", "automobile", "roll"],
        nudge: "Car plus bun. That is the element of coal, pencil, and diamond.",
      },
    ],
    near: [
      {
        words: ["coal", "diamond", "graphite", "charcoal", "organic"],
        nudge: "Those are costumes carbon wears. The element is car-bun.",
      },
    ],
    explanation: "A car and a bun. Car-bun — carbon, the element of coal, pencil lead, and diamond.",
    fact: "Carbon is atomic number 6. Life’s chemistry is built on its talent for bonding to itself.",
    difficulty: 2,
  },
  {
    id: "oxygen",
    category: "chemistry",
    answer: "Oxygen",
    aliases: ["o"],
    prompt: "Guess the element",
    say: "ox + gin",
    hints: [
      "A beast of burden and a juniper bottle. Together they are the gas in the breath.",
      "OX · GIN",
      "O",
    ],
    literal: [
      {
        words: ["ox", "gin", "bottle", "juniper", "bull", "cow"],
        nudge: "Ox plus the juniper bottle. Say them as the element.",
      },
    ],
    near: [
      {
        words: ["o2", "air", "hydrogen", "nitrogen", "ozone"],
        nudge: "O₂ is the molecule in the air. The frame wants the element: ox-gin.",
      },
    ],
    explanation: "An ox and a bottle of gin. Ox-gin — oxygen, the gas that brightens a flame and a breath.",
    fact: "Oxygen is atomic number 8. It is about a fifth of Earth’s air by volume, and most of the mass of the human body.",
    difficulty: 2,
  },
  {
    id: "zinc",
    category: "chemistry",
    answer: "Zinc",
    aliases: ["zn"],
    prompt: "Guess the element",
    say: "sink",
    hints: [
      "You could wash your hands here. Say the fixture with a Z.",
      "It sounds like the basin.",
      "Z",
    ],
    literal: [
      {
        words: ["sink", "basin", "faucet", "tap", "washbasin"],
        nudge: "That’s the fixture. The element is one letter away, and it keeps iron from rusting.",
      },
    ],
    near: [
      {
        words: ["iron", "tin", "copper", "galvanize", "brass"],
        nudge: "A metal neighbor. This one sounds like the sink and galvanizes the others.",
      },
    ],
    explanation: "A sink. Say it with a Z and you have zinc, the metal that galvanizes iron against rust.",
    fact: "Zinc is atomic number 30. Brass is copper married to zinc.",
    difficulty: 1,
  },
  {
    id: "catalyst",
    category: "chemistry",
    answer: "Catalyst",
    aliases: ["catalysts"],
    prompt: "Guess the helper in the reaction",
    say: "cat + a list",
    hints: [
      "A cat, and a checklist. The reaction beside them runs faster, and the cat is not used up.",
      "CAT · A · LIST",
      "C",
    ],
    literal: [
      {
        words: ["cat", "list", "checklist", "kitten", "clipboard"],
        nudge: "Cat, a list. That is the word for a helper that speeds a reaction and walks away unchanged.",
      },
    ],
    near: [
      {
        words: ["enzyme", "reactant", "product", "inhibitor"],
        nudge: "An enzyme is a biological one of these. The frame wants the general word: cat-a-list.",
      },
    ],
    explanation: "A cat with a list. Cat-a-list — a catalyst, which speeds a reaction and is not consumed.",
    fact: "A single enzyme molecule, a biological catalyst, can turn over thousands of reactions a second and still be itself at the end.",
    difficulty: 2,
  },
  {
    id: "anion",
    category: "chemistry",
    answer: "Anion",
    aliases: ["negative ion"],
    prompt: "Guess the ion",
    say: "an onion, minus",
    hints: [
      "It looks like a vegetable and wears a minus sign. It has gained electrons.",
      "AN · ONION, with a minus.",
      "A",
    ],
    literal: [
      {
        words: ["onion", "vegetable", "minus", "negative"],
        nudge: "An onion, wearing a minus. Say it as the ion.",
      },
    ],
    near: [
      {
        words: ["ion", "cation", "electron", "atom"],
        nudge: "Which kind of ion? The sign is negative, and the vegetable is an onion.",
      },
    ],
    explanation: "An onion wearing a minus. Anion — a negatively charged ion, one that has gained electrons.",
    fact: "In electrolysis, anions drift toward the anode. The names were built to remember each other.",
    difficulty: 2,
  },
  {
    id: "cation",
    category: "chemistry",
    answer: "Cation",
    aliases: ["positive ion", "cat-ion"],
    prompt: "Guess the ion",
    say: "cat + ion",
    hints: [
      "A cat wearing a plus. It has lost electrons.",
      "CAT · ION",
      "C",
    ],
    literal: [
      {
        words: ["cat", "kitten", "plus", "positive"],
        nudge: "A cat, and the plus sign makes it an ion of a particular kind.",
      },
    ],
    near: [
      {
        words: ["ion", "anion", "proton", "atom"],
        nudge: "The sign is positive. Cat plus ion — say it as one word.",
      },
    ],
    explanation: "A cat with a plus. Cat-ion — a cation, a positively charged ion.",
    fact: "In table salt, sodium arrives as the cation Na⁺ and chlorine as the anion Cl⁻.",
    difficulty: 2,
  },
  {
    id: "polymer",
    category: "chemistry",
    answer: "Polymer",
    aliases: ["polymers"],
    prompt: "Guess the kind of molecule",
    say: "Polly + mer",
    hints: [
      "A parrot’s name, and a figure with a tail. The beads are the repeating units.",
      "POLLY · MER",
      "P",
    ],
    literal: [
      {
        words: ["parrot", "polly", "mermaid", "fish", "beads"],
        nudge: "Polly the parrot, beside a mer. That is a long chain of repeating units.",
      },
    ],
    near: [
      {
        words: ["monomer", "plastic", "protein", "chain"],
        nudge: "The beads are the monomers. The long chain they make is Polly-mer.",
      },
    ],
    explanation: "Polly the parrot beside a mermaid. Polly-mer — a polymer, a long chain of repeating units.",
    fact: "Proteins, starch, DNA, and most plastics are polymers. The repeating piece is the monomer.",
    difficulty: 3,
  },
  {
    id: "bromine",
    category: "chemistry",
    answer: "Bromine",
    aliases: ["br"],
    prompt: "Guess the element",
    say: "broom + mine",
    hints: [
      "A broom at the mouth of a mine. The puddle is red-brown for a reason.",
      "BROOM · MINE",
      "B",
    ],
    literal: [
      {
        words: ["broom", "mine", "mining", "tunnel", "cart"],
        nudge: "Broom plus mine. The red-brown puddle is the element itself, which is liquid at room temperature.",
      },
    ],
    near: [
      {
        words: ["chlorine", "iodine", "mercury", "halogen"],
        nudge: "A halogen neighbor. This one is the broom at the mine, and one of only two liquid elements.",
      },
    ],
    explanation: "A broom at a mine. Broom-mine — bromine, a deep red-brown element liquid at room temperature.",
    fact: "Bromine is atomic number 35. At an ordinary room temperature, only bromine and mercury are liquids.",
    difficulty: 2,
  },
  {
    id: "halogen",
    category: "chemistry",
    answer: "Halogen",
    aliases: ["halogens"],
    prompt: "Guess the element family",
    say: "halo + gin",
    hints: [
      "A halo over a juniper bottle. Salt crystals at the base are the family’s reputation.",
      "HALO · GIN",
      "H",
    ],
    literal: [
      {
        words: ["halo", "gin", "bottle", "angel", "salt"],
        nudge: "Halo plus gin. The family is famous for forming salts.",
      },
    ],
    near: [
      {
        words: ["fluorine", "chlorine", "bromine", "iodine", "noble gas", "alkali"],
        nudge: "Those are members, or a different column. The family name is halo-gin.",
      },
    ],
    explanation: "A halo over a bottle of gin. Halo-gin — the halogens: fluorine, chlorine, bromine, iodine, astatine.",
    fact: "Halogen means salt-former. Sodium and chlorine, a halogen, make the salt on the table.",
    difficulty: 3,
  },
  {
    id: "gene",
    category: "biology",
    answer: "Gene",
    aliases: ["genes"],
    prompt: "Guess the unit of heredity",
    say: "jeans",
    hints: [
      "They are hanging on the line. In the cell, they are stretches of DNA.",
      "It sounds like the trousers.",
      "G",
    ],
    literal: [
      {
        words: ["jeans", "pants", "trousers", "denim", "clothes"],
        nudge: "Those are the costume. The unit of heredity is the homophone.",
      },
    ],
    near: [
      {
        words: ["dna", "chromosome", "allele", "trait"],
        nudge: "DNA is the molecule; a chromosome is the package. The unit that sounds like the trousers is smaller.",
      },
    ],
    explanation: "Jeans on a line. Jeans — genes, the stretches of DNA a cell reads when it builds a trait.",
    fact: "Humans have on the order of 20,000 protein-coding genes, far fewer than the old guess of 100,000.",
    difficulty: 1,
  },
  {
    id: "dna",
    category: "biology",
    answer: "DNA",
    aliases: ["dna", "deoxyribonucleic acid", "deoxyribonucleicacid"],
    prompt: "Guess the molecule",
    say: "a twisted ladder",
    hints: [
      "Two ribbons, rungs in pairs, twisting. It stores hereditary information.",
      "Three letters. The full name is a mouthful beginning with deoxy.",
      "D",
    ],
    literal: [
      {
        words: ["ladder", "helix", "staircase", "spiral", "twist"],
        nudge: "That’s the shape. The molecule’s short name is three letters.",
      },
    ],
    near: [
      {
        words: ["rna", "gene", "chromosome", "protein", "helix"],
        nudge: "RNA is the cousin with one strand. This double ladder is the archive.",
      },
    ],
    explanation: "A twisted ladder of paired rungs. DNA — deoxyribonucleic acid — stores hereditary information.",
    fact: "The two strands run in opposite directions. Adenine pairs with thymine, guanine with cytosine.",
    difficulty: 1,
  },
  {
    id: "fungus",
    category: "biology",
    answer: "Fungus",
    aliases: ["fungi"],
    prompt: "Guess the kingdom",
    say: "a fun Gus",
    hints: [
      "Read the name tag, and notice the mood. He is a whole kingdom.",
      "FUN · GUS",
      "F",
    ],
    literal: [
      {
        words: ["gus", "mushroom", "party", "fun", "toadstool"],
        nudge: "A fun Gus. Say it as the kingdom of mushrooms, molds, and yeasts.",
      },
    ],
    near: [
      {
        words: ["plant", "mushroom", "mycelium", "mold", "yeast"],
        nudge: "Mushrooms belong to it, but they are not plants. The kingdom is the name tag plus the mood.",
      },
    ],
    explanation: "A fun Gus. Fun-gus — the kingdom of mushrooms, molds, and yeasts.",
    fact: "Fungi are genetically closer to animals than to plants. Their cell walls are chitin, the same material as an insect’s shell.",
    difficulty: 1,
  },
  {
    id: "heart",
    category: "biology",
    answer: "Heart",
    aliases: [],
    prompt: "Guess the organ",
    say: "hart",
    hints: [
      "The old word for a stag sounds exactly like the organ. The marking on the flank agrees.",
      "It sounds like the deer.",
      "H",
    ],
    literal: [
      {
        words: ["hart", "deer", "stag", "antlers", "buck"],
        nudge: "That’s the deer. The organ that sounds like “hart” is the pump.",
      },
    ],
    near: [
      {
        words: ["lung", "liver", "blood", "chest"],
        nudge: "Nearby anatomy. This one is the muscular pump, and the pun is the stag.",
      },
    ],
    explanation: "A hart — the old word for a stag. Hart and heart are sound-twins. The organ is the pump of the circulation.",
    fact: "A resting human heart beats on the order of 100,000 times a day, and does not ask for applause.",
    difficulty: 2,
  },
  {
    id: "kidney",
    category: "biology",
    answer: "Kidney",
    aliases: ["kidneys"],
    prompt: "Guess the organ",
    say: "kid + knee",
    hints: [
      "A child, and the joint being pointed at. Together they filter the blood.",
      "KID · KNEE",
      "K",
    ],
    literal: [
      {
        words: ["kid", "child", "knee", "boy", "girl"],
        nudge: "A kid’s knee. Say them as the organ that filters blood.",
      },
    ],
    near: [
      {
        words: ["liver", "elbow", "leg", "bladder"],
        nudge: "The knee is the costume. The organ is kid-knee, about the size of a fist.",
      },
    ],
    explanation: "A kid’s knee. Kid-knee — the kidney, which filters blood and balances water and salts.",
    fact: "You can live well with one kidney. Each filters the body’s blood many times a day.",
    difficulty: 2,
  },
  {
    id: "habitat",
    category: "biology",
    answer: "Habitat",
    aliases: ["habitats"],
    prompt: "Guess the ecological term",
    say: "habit + bat",
    hints: [
      "A monk’s robe is called a habit. Something small is asleep in the hood.",
      "HABIT · AT  (the robe, and the bat)",
      "H",
    ],
    literal: [
      {
        words: ["habit", "robe", "monk", "bat", "cave", "hood"],
        nudge: "A habit, and a bat. That is the word for a species’ natural home.",
      },
    ],
    near: [
      {
        words: ["niche", "ecosystem", "biome", "home", "environment"],
        nudge: "A niche is the role; this frame is the place itself. Habit plus bat.",
      },
    ],
    explanation: "A habit and a bat. Habit-at — a habitat, the natural home where a species actually lives.",
    fact: "A habitat supplies food, water, shelter, and space. A niche is the role a species plays inside one.",
    difficulty: 2,
  },
  {
    id: "vaccine",
    category: "biology",
    answer: "Vaccine",
    aliases: ["vaccines", "vaccination"],
    prompt: "Guess the medicine",
    say: "vacca, the cow",
    hints: [
      "The animal is the etymology. Latin for cow is hiding in the medicine’s name.",
      "From vacca, Latin for the animal in the frame.",
      "V",
    ],
    literal: [
      {
        words: ["cow", "shield", "milk", "pail", "cattle"],
        nudge: "The cow is the clue, not the answer. The medicine is named from the Latin for cow.",
      },
    ],
    near: [
      {
        words: ["cowpox", "smallpox", "immunity", "antibody", "jenner", "inoculation"],
        nudge: "Cowpox was the observation. The medicine that came from it is named for the cow.",
      },
    ],
    explanation:
      "A cow with a shield. Vaccine comes from vacca, Latin for cow — Jenner’s cowpox observations led to vaccination.",
    fact: "In 1796 Edward Jenner showed that cowpox could protect against smallpox. The word still remembers the cow.",
    difficulty: 3,
  },
  {
    id: "mitochondria",
    category: "biology",
    answer: "Mitochondria",
    aliases: ["mitochondrion", "the mitochondria", "the mitochondrion"],
    prompt: "Guess the organelle",
    say: "the powerhouse of the cell",
    hints: [
      "Every textbook calls it the powerhouse. It sits inside the cell, bean-shaped, making ATP.",
      "The nickname is “powerhouse.” The real name is longer.",
      "M",
    ],
    literal: [
      {
        words: ["powerhouse", "power plant", "powerstation", "factory", "cell", "lightning", "bean"],
        nudge: "That’s the nickname every textbook uses. What is the organelle’s real name?",
      },
    ],
    near: [
      {
        words: ["chloroplast", "nucleus", "ribosome", "atp", "cytoplasm"],
        nudge: "A neighbor in the cell. This one is the bean-shaped powerhouse.",
      },
    ],
    explanation: "The powerhouse inside the cell. Mitochondria release usable energy from food as ATP.",
    fact: "Mitochondria keep their own small loop of DNA, a clue that they were once free-living bacteria.",
    difficulty: 2,
  },
  {
    id: "xylem",
    category: "biology",
    answer: "Xylem",
    aliases: [],
    prompt: "Guess the plant tissue",
    say: "xylophone",
    hints: [
      "The instrument inside the stem is almost the whole word. Water is the cargo.",
      "It sounds like the xylophone, shortened.",
      "X",
    ],
    literal: [
      {
        words: ["xylophone", "music", "stem", "plant", "instrument"],
        nudge: "The instrument is the costume. The tissue that pipes water up a stem sounds like it.",
      },
    ],
    near: [
      {
        words: ["phloem", "root", "wood", "vascular"],
        nudge: "Phloem carries sugars. This one carries water, and it sounds like the instrument.",
      },
    ],
    explanation: "A xylophone inside a stem. Xylem — the tissue that pipes water and minerals from roots to leaves.",
    fact: "Xylem cells are often dead at maturity: hollow tubes stiffened with lignin. Wood is mostly xylem.",
    difficulty: 3,
  },
  {
    id: "tissue",
    category: "biology",
    answer: "Tissue",
    aliases: ["tissues"],
    prompt: "Guess the level of organization",
    say: "a box of tissues",
    hints: [
      "The box is a pun, and the print on each sheet is cells holding hands.",
      "The box and the biological level share a name.",
      "T",
    ],
    literal: [
      {
        words: ["tissue box", "box", "kleenex", "handkerchief", "cells"],
        nudge: "Cells are the print on the sheet. What do we call a group of similar cells doing one job?",
      },
    ],
    near: [
      {
        words: ["organ", "cell", "organism", "organ system"],
        nudge: "Cells gather into this, and these gather into organs. The box is naming the middle step.",
      },
    ],
    explanation: "A box of tissues, printed with cells holding hands. A tissue is a group of similar cells doing one job.",
    fact: "Animals are classically given four tissue types: epithelial, connective, muscle, and nervous.",
    difficulty: 1,
  },
];

export function puzzlesIn(category: Category): Puzzle[] {
  return puzzles.filter((p) => p.category === category);
}

export function puzzleById(id: string): Puzzle | undefined {
  return puzzles.find((p) => p.id === id);
}

export function dailyPuzzle(date = new Date()): Puzzle {
  const start = Date.UTC(date.getFullYear(), 0, 0);
  const day = Math.floor((Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) - start) / 86400000);
  const idx = (day * 7 + 3) % puzzles.length;
  return puzzles[idx];
}

export function wingOf(id: Category) {
  return wings.find((w) => w.id === id)!;
}
